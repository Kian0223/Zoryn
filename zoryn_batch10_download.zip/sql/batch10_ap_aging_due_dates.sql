ALTER TABLE grocery_purchases
  ADD COLUMN due_date DATE DEFAULT NULL AFTER purchase_date,
  ADD COLUMN expense_posted TINYINT(1) NOT NULL DEFAULT 0 AFTER payment_status;

CREATE TABLE IF NOT EXISTS ap_terms (
  id INT(11) NOT NULL AUTO_INCREMENT,
  supplier_id INT(11) DEFAULT NULL,
  term_name VARCHAR(100) NOT NULL,
  days_due INT(11) NOT NULL DEFAULT 0,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
