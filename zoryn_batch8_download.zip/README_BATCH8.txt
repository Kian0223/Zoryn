ZORYN BATCH 8 INSTALLATION
==========================

This batch adds:
- Supplier management
- Grocery purchase draft + receiving
- Inventory valuation / summary report

INSTALL ORDER
-------------
1. Run: sql/batch8_suppliers_purchases_inventory.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch8.css if you want the extra styling

ROUTES ADDED
------------
/suppliers/index
/suppliers/store
/suppliers/update/{id}
 /suppliers/delete/{id}
/grocerypurchases/index
/grocerypurchases/store
/grocerypurchases/receive/{id}
 /grocerypurchases/cancel/{id}
/inventorysummary/index

NOTES
-----
- Receiving a draft grocery purchase updates grocery stock and latest unit cost.
- Draft purchases do not affect stock until received.
- Inventory Summary is based on groceries.current_stock * groceries.latest_cost.
