<?php
class Grocery extends Model
{
    public function getAll(): array
    {
        $this->db->query("
            SELECT *,
                   CASE
                       WHEN current_stock <= 0 THEN 'out'
                       WHEN current_stock <= low_stock_threshold THEN 'low'
                       ELSE 'ok'
                   END AS stock_status
            FROM groceries
            ORDER BY grocery_name ASC
        ");
        return $this->db->resultSet();
    }

    public function getLowStockCount(): int
    {
        $this->db->query("SELECT COUNT(*) AS total FROM groceries WHERE current_stock <= low_stock_threshold");
        $row = $this->db->single();
        return (int)($row['total'] ?? 0);
    }

    public function getOutOfStockCount(): int
    {
        $this->db->query("SELECT COUNT(*) AS total FROM groceries WHERE current_stock <= 0");
        $row = $this->db->single();
        return (int)($row['total'] ?? 0);
    }

    public function findById(int $id): array|false
    {
        $this->db->query("SELECT * FROM groceries WHERE id = :id LIMIT 1");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    public function receiveStock(int $id, float $packageCount, float $packageQuantity, float $packageCost): bool
    {
        $totalQuantity = $packageCount * $packageQuantity;
        $latestCost = $packageQuantity > 0 ? ($packageCost / $packageQuantity) : 0;

        $this->db->query("
            UPDATE groceries
            SET current_stock = current_stock + :total_quantity,
                package_quantity = :package_quantity,
                package_cost = :package_cost,
                latest_cost = :latest_cost
            WHERE id = :id
        ");
        $this->db->bind(':total_quantity', $totalQuantity);
        $this->db->bind(':package_quantity', $packageQuantity);
        $this->db->bind(':package_cost', $packageCost);
        $this->db->bind(':latest_cost', $latestCost);
        $this->db->bind(':id', $id);

        return $this->db->execute();
    }

    public function adjustStock(int $id, float $quantity): bool
    {
        $this->db->query("UPDATE groceries SET current_stock = current_stock + :quantity WHERE id = :id");
        $this->db->bind(':quantity', $quantity);
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function getInventoryValuation(): array
    {
        $this->db->query("
            SELECT
                id,
                grocery_name,
                unit,
                current_stock,
                low_stock_threshold,
                package_quantity,
                package_cost,
                latest_cost,
                (current_stock * latest_cost) AS stock_value
            FROM groceries
            ORDER BY grocery_name ASC
        ");
        return $this->db->resultSet();
    }

    public function getInventoryTotals(): array
    {
        $this->db->query("
            SELECT
                COUNT(*) AS total_items,
                COALESCE(SUM(current_stock * latest_cost), 0) AS total_stock_value,
                SUM(CASE WHEN current_stock <= low_stock_threshold THEN 1 ELSE 0 END) AS low_stock_items
            FROM groceries
        ");
        return $this->db->single() ?: [
            'total_items' => 0,
            'total_stock_value' => 0,
            'low_stock_items' => 0,
        ];
    }
}
