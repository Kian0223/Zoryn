ZORYN BATCH 15 INSTALLATION
===========================

This batch adds:
- Employee records
- Role and permission tables
- Attendance logging
- Payroll-ready summaries

INSTALL ORDER
-------------
1. Run: sql/batch15_hr_permissions_attendance.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch15.css if you want the extra styling

ROUTES ADDED
------------
/employees/index
/employees/store
/attendance/index
/attendance/store
/payroll/index

NOTES
-----
- Payroll summary is based on attendance hours x hourly rate.
- Overtime uses 1.25x hourly rate in this batch.
- Role permissions tables are included, but route-level enforcement is not yet added.
