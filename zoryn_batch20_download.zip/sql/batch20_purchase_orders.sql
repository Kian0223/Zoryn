CREATE TABLE IF NOT EXISTS supplier_purchase_orders (
  id INT(11) NOT NULL AUTO_INCREMENT,
  po_no VARCHAR(50) NOT NULL,
  plan_id INT(11) DEFAULT NULL,
  supplier_id INT(11) NOT NULL,
  po_date DATE NOT NULL,
  expected_date DATE DEFAULT NULL,
  status ENUM('draft','issued','partially_received','received','cancelled') NOT NULL DEFAULT 'draft',
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  notes VARCHAR(255) DEFAULT NULL,
  created_by INT(11) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uq_supplier_po_no (po_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS supplier_purchase_order_items (
  id INT(11) NOT NULL AUTO_INCREMENT,
  po_id INT(11) NOT NULL,
  plan_item_id INT(11) DEFAULT NULL,
  grocery_id INT(11) NOT NULL,
  ordered_qty DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  received_qty DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  line_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE grocery_purchases
  ADD COLUMN source_po_id INT(11) DEFAULT NULL AFTER supplier_id;
