<?php
class Sale extends Model
{
    public function createSaleReturningId(array $header, array $items): int|false
    {
        $receiptNo = 'REC-' . date('Ymd-His') . '-' . rand(100, 999);
        $saleDate = date('Y-m-d H:i:s');
        $grossAmount = 0;
        foreach ($items as $item) $grossAmount += (float)$item['line_total'];

        $paymentMethod = $header['payment_method'] ?? 'cash';
        $paymentReference = trim((string)($header['payment_reference'] ?? '')) ?: null;
        $customerId = $header['customer_id'] ?? null;
        $pointsEarned = isset($header['loyalty_points_earned']) ? (float)$header['loyalty_points_earned'] : 0;
        $pointsRedeemed = isset($header['loyalty_points_redeemed']) ? (float)$header['loyalty_points_redeemed'] : 0;
        $promoId = $header['promo_id'] ?? null;
        $promoDiscount = isset($header['promo_discount_amount']) ? (float)$header['promo_discount_amount'] : 0;

        $netTotal = max(0, $grossAmount - $pointsRedeemed - $promoDiscount);
        $paidAmount = isset($header['paid_amount']) ? (float)$header['paid_amount'] : $netTotal;
        $changeAmount = max(0, $paidAmount - $netTotal);

        $this->db->query("
            INSERT INTO sales (
                receipt_no, sale_date, total_amount, payment_method, payment_reference,
                paid_amount, change_amount, sale_status, created_by, customer_id,
                loyalty_points_earned, loyalty_points_redeemed, promo_id, promo_discount_amount
            ) VALUES (
                :receipt_no, :sale_date, :total_amount, :payment_method, :payment_reference,
                :paid_amount, :change_amount, 'completed', :created_by, :customer_id,
                :loyalty_points_earned, :loyalty_points_redeemed, :promo_id, :promo_discount_amount
            )
        ");
        $this->db->bind(':receipt_no', $receiptNo);
        $this->db->bind(':sale_date', $saleDate);
        $this->db->bind(':total_amount', $netTotal);
        $this->db->bind(':payment_method', $paymentMethod);
        $this->db->bind(':payment_reference', $paymentReference);
        $this->db->bind(':paid_amount', $paidAmount);
        $this->db->bind(':change_amount', $changeAmount);
        $this->db->bind(':created_by', $header['created_by'] ?? null);
        $this->db->bind(':customer_id', $customerId);
        $this->db->bind(':loyalty_points_earned', $pointsEarned);
        $this->db->bind(':loyalty_points_redeemed', $pointsRedeemed);
        $this->db->bind(':promo_id', $promoId);
        $this->db->bind(':promo_discount_amount', $promoDiscount);

        if (!$this->db->execute()) return false;

        $saleId = (int)$this->db->lastInsertId();
        foreach ($items as $item) {
            $this->db->query("
                INSERT INTO sale_items (sale_id, viand_id, product_id, quantity, unit_price, line_total)
                VALUES (:sale_id, :viand_id, :product_id, :quantity, :unit_price, :line_total)
            ");
            $this->db->bind(':sale_id', $saleId);
            $this->db->bind(':viand_id', $item['viand_id']);
            $this->db->bind(':product_id', $item['product_id']);
            $this->db->bind(':quantity', $item['quantity']);
            $this->db->bind(':unit_price', $item['unit_price']);
            $this->db->bind(':line_total', $item['line_total']);
            if (!$this->db->execute()) return false;
        }

        return $saleId;
    }
}
