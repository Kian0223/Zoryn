<?php
class OrdersController extends Controller
{
    public function index(): void
    {
        $this->requireLogin();

        $orderModel = $this->model('Order');
        $tableModel = $this->model('DiningTable');
        $productModel = $this->model('Product');
        $viandModel = $this->model('Viand');

        $prefill = null;
        $reservationId = (int)($_GET['reservation_id'] ?? 0);
        if ($reservationId > 0) {
            $reservationModel = $this->model('Reservation');
            $reservation = $reservationModel->findById($reservationId);
            if ($reservation) {
                $prefill = [
                    'reservation_id' => $reservationId,
                    'order_type' => !empty($reservation['table_id']) ? 'dine_in' : 'takeout',
                    'table_id' => $reservation['table_id'] ?? '',
                    'customer_name' => $reservation['customer_name'] ?? '',
                    'customer_phone' => $reservation['customer_phone'] ?? '',
                    'notes' => 'From reservation ' . ($reservation['reservation_no'] ?? ''),
                ];
            }
        }

        $this->view('orders/index', [
            'title' => 'Orders',
            'orders' => $orderModel->getAllWithItems(),
            'tables' => $tableModel->getAll(),
            'products' => $productModel->getAll(),
            'viands' => $viandModel->getAllWithCost(),
            'counts' => $orderModel->getCounts(),
            'prefill' => $prefill,
        ]);
    }

    public function store(): void
    {
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('orders/index');
            return;
        }

        $orderType = trim($_POST['order_type'] ?? 'dine_in');
        $tableId = (int)($_POST['table_id'] ?? 0);
        $customerName = trim($_POST['customer_name'] ?? '');
        $customerPhone = trim($_POST['customer_phone'] ?? '');
        $notes = trim($_POST['notes'] ?? '');

        $productIds = $_POST['product_id'] ?? [];
        $viandIds = $_POST['viand_id'] ?? [];
        $quantities = $_POST['quantity'] ?? [];
        $unitPrices = $_POST['unit_price'] ?? [];
        $types = $_POST['item_type'] ?? [];
        $itemNotes = $_POST['item_notes'] ?? [];

        if ($orderType === 'dine_in' && $tableId <= 0) {
            $_SESSION['error'] = 'Please select a table for dine-in orders.';
            $this->redirect('orders/index');
            return;
        }

        $items = [];
        foreach ($types as $i => $type) {
            $qty = (float)($quantities[$i] ?? 0);
            $price = (float)($unitPrices[$i] ?? 0);
            if ($qty <= 0 || $price < 0) continue;

            $productId = !empty($productIds[$i]) ? (int)$productIds[$i] : null;
            $viandId = !empty($viandIds[$i]) ? (int)$viandIds[$i] : null;

            if ($type === 'product' && !$productId) continue;
            if ($type === 'viand' && !$viandId) continue;

            $items[] = [
                'product_id' => $type === 'product' ? $productId : null,
                'viand_id' => $type === 'viand' ? $viandId : null,
                'quantity' => $qty,
                'unit_price' => $price,
                'line_total' => $qty * $price,
                'notes' => trim($itemNotes[$i] ?? ''),
            ];
        }

        if (empty($items)) {
            $_SESSION['error'] = 'Please add at least one order item.';
            $this->redirect('orders/index');
            return;
        }

        $orderModel = $this->model('Order');
        $orderId = $orderModel->createOrder([
            'order_type' => $orderType,
            'table_id' => $tableId > 0 ? $tableId : null,
            'customer_name' => $customerName,
            'customer_phone' => $customerPhone,
            'notes' => $notes,
            'created_by' => $_SESSION['user']['id'] ?? null,
        ], $items);

        if (!$orderId) {
            $_SESSION['error'] = 'Failed to create order.';
            $this->redirect('orders/index');
            return;
        }

        if ($orderType === 'dine_in' && $tableId > 0) {
            $tableModel = $this->model('DiningTable');
            $tableModel->setStatus($tableId, 'occupied');
        }

        $_SESSION['success'] = 'Order created successfully.';
        $this->redirect('orders/index');
    }

    public function updateStatus($id): void
    {
        $this->requireLogin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('orders/index');
            return;
        }

        $orderId = (int)$id;
        $status = trim($_POST['status'] ?? '');

        $orderModel = $this->model('Order');
        $tableModel = $this->model('DiningTable');

        $order = $orderModel->findById($orderId);
        if (!$order) {
            $_SESSION['error'] = 'Order not found.';
            $this->redirect('orders/index');
            return;
        }

        if (!$orderModel->updateStatus($orderId, $status)) {
            $_SESSION['error'] = 'Failed to update order status.';
            $this->redirect('orders/index');
            return;
        }

        if (!empty($order['table_id'])) {
            if (in_array($status, ['pending', 'preparing', 'ready', 'served'], true)) {
                $tableModel->setStatus((int)$order['table_id'], 'occupied');
            } elseif (in_array($status, ['completed', 'cancelled'], true)) {
                $tableModel->setStatus((int)$order['table_id'], 'available');
            }
        }

        $_SESSION['success'] = 'Order status updated successfully.';
        $this->redirect('orders/index');
    }

    public function kitchenTicket($id): void
    {
        $this->requireLogin();
        $orderModel = $this->model('Order');
        $order = $orderModel->findByIdWithItems((int)$id);

        if (!$order) {
            $_SESSION['error'] = 'Order not found.';
            $this->redirect('orders/index');
            return;
        }

        $this->view('orders/kitchen_ticket', [
            'title' => 'Kitchen Ticket',
            'order' => $order,
        ]);
    }

    public function bill($id): void
    {
        $this->requireLogin();
        $orderModel = $this->model('Order');
        $order = $orderModel->findByIdWithItems((int)$id);

        if (!$order) {
            $_SESSION['error'] = 'Order not found.';
            $this->redirect('orders/index');
            return;
        }

        $this->view('orders/bill', [
            'title' => 'Bill Preview',
            'order' => $order,
        ]);
    }

    public function checkout($id): void
    {
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $_SESSION['error'] = 'Invalid checkout request.';
            $this->redirect('orders/index');
            return;
        }

        $orderModel = $this->model('Order');
        $saleModel = $this->model('Sale');
        $productModel = $this->model('Product');
        $viandModel = $this->model('Viand');
        $groceryModel = $this->model('Grocery');
        $tableModel = $this->model('DiningTable');

        $order = $orderModel->findByIdWithItems((int)$id);
        if (!$order) {
            $_SESSION['error'] = 'Order not found.';
            $this->redirect('orders/index');
            return;
        }

        if (!empty($order['sale_id'])) {
            $_SESSION['success'] = 'Order already checked out.';
            $this->redirect('orders/receipt/' . (int)$order['id']);
            return;
        }

        $paymentMethod = trim($_POST['payment_method'] ?? 'cash');
        $paymentReference = trim($_POST['payment_reference'] ?? '');
        $paidAmount = (float)($_POST['paid_amount'] ?? 0);

        $items = [];
        $orderTotal = 0;

        foreach (($order['items'] ?? []) as $item) {
            $qty = (float)($item['quantity'] ?? 0);
            $unitPrice = (float)($item['unit_price'] ?? 0);
            $lineTotal = $qty * $unitPrice;
            $orderTotal += $lineTotal;

            $items[] = [
                'product_id' => !empty($item['product_id']) ? (int)$item['product_id'] : null,
                'viand_id' => !empty($item['viand_id']) ? (int)$item['viand_id'] : null,
                'quantity' => $qty,
                'unit_price' => $unitPrice,
                'line_total' => $lineTotal,
            ];
        }

        if ($paidAmount < $orderTotal) {
            $_SESSION['error'] = 'Paid amount is less than the bill total.';
            $this->redirect('orders/index');
            return;
        }

        foreach (($order['items'] ?? []) as $item) {
            $qty = (float)($item['quantity'] ?? 0);

            if (!empty($item['product_id'])) {
                $productModel->adjustStock((int)$item['product_id'], -$qty);
            }

            if (!empty($item['viand_id'])) {
                $ingredients = $viandModel->getIngredientsByViand((int)$item['viand_id']);
                foreach ($ingredients as $ingredient) {
                    $groceryId = (int)($ingredient['grocery_id'] ?? 0);
                    $quantityNeededPerServing = (float)($ingredient['quantity_needed'] ?? 0);
                    if ($groceryId <= 0 || $quantityNeededPerServing <= 0) continue;
                    $groceryModel->adjustStock($groceryId, -($quantityNeededPerServing * $qty));
                }
            }
        }

        $saleId = $saleModel->createSaleReturningId([
            'created_by' => $_SESSION['user']['id'] ?? null,
            'payment_method' => $paymentMethod,
            'payment_reference' => $paymentReference,
            'paid_amount' => $paidAmount,
        ], $items);

        if (!$saleId) {
            $_SESSION['error'] = 'Failed to complete checkout.';
            $this->redirect('orders/index');
            return;
        }

        $orderModel->attachSale((int)$order['id'], $saleId);

        if (!empty($order['table_id'])) {
            $tableModel->setStatus((int)$order['table_id'], 'available');
        }

        $_SESSION['success'] = 'Order checked out successfully.';
        $this->redirect('orders/receipt/' . (int)$order['id']);
    }

    public function receipt($id): void
    {
        $this->requireLogin();

        $orderModel = $this->model('Order');
        $saleModel = $this->model('Sale');

        $order = $orderModel->findByIdWithItems((int)$id);
        if (!$order) {
            $_SESSION['error'] = 'Order not found.';
            $this->redirect('orders/index');
            return;
        }

        if (empty($order['sale_id'])) {
            $_SESSION['error'] = 'This order has no completed receipt yet.';
            $this->redirect('orders/index');
            return;
        }

        $sale = $saleModel->findByIdWithItems((int)$order['sale_id']);
        if (!$sale) {
            $_SESSION['error'] = 'Receipt not found.';
            $this->redirect('orders/index');
            return;
        }

        $this->view('orders/receipt', [
            'title' => 'Receipt',
            'order' => $order,
            'sale' => $sale,
        ]);
    }
}
