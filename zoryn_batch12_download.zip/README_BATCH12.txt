ZORYN BATCH 12 INSTALLATION
===========================

This batch adds:
- Menu engineering report
- Best-selling viands report
- Best-selling products report
- Slow-moving groceries report
- Slow-moving products report

INSTALL ORDER
-------------
1. No required SQL change for this batch
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch12.css if you want the extra styling

ROUTES ADDED
------------
/reporting/index

NOTES
-----
- Menu engineering class is based on average popularity and average profit.
- Slow-moving groceries are estimated using viand ingredient usage from completed sales.
- Slow-moving products are based on low sold quantity with available on-hand stock.
