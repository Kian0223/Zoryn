<?php
class Sale extends Model
{
    public function getTodaySalesAmount(): float
    {
        $this->db->query("SELECT COALESCE(SUM(total_amount), 0) AS total FROM sales WHERE DATE(sale_date) = CURDATE()");
        $row = $this->db->single();
        return (float)($row['total'] ?? 0);
    }

    public function getTotalSalesCount(): int
    {
        $this->db->query("SELECT COUNT(*) AS total FROM sales");
        $row = $this->db->single();
        return (int)($row['total'] ?? 0);
    }

    public function getRangeSummary(?string $dateFrom = null, ?string $dateTo = null): array
    {
        $where = [];
        if ($dateFrom) $where[] = "DATE(sale_date) >= :date_from";
        if ($dateTo) $where[] = "DATE(sale_date) <= :date_to";

        $sql = "SELECT 
                    COUNT(*) AS total_receipts,
                    COALESCE(SUM(total_amount), 0) AS total_sales,
                    COALESCE(AVG(total_amount), 0) AS avg_order
                FROM sales";
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);

        $this->db->query($sql);
        if ($dateFrom) $this->db->bind(':date_from', $dateFrom);
        if ($dateTo) $this->db->bind(':date_to', $dateTo);

        $row = $this->db->single() ?: [];
        return [
            'total_receipts' => (int)($row['total_receipts'] ?? 0),
            'total_sales' => (float)($row['total_sales'] ?? 0),
            'avg_order' => (float)($row['avg_order'] ?? 0),
        ];
    }

    public function getSalesWithItems(?string $dateFrom = null, ?string $dateTo = null): array
    {
        $where = [];
        if ($dateFrom) $where[] = "DATE(s.sale_date) >= :date_from";
        if ($dateTo) $where[] = "DATE(s.sale_date) <= :date_to";

        $sql = "SELECT s.*, u.full_name AS cashier_name
                FROM sales s
                LEFT JOIN users u ON u.id = s.created_by";
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
        $sql .= ' ORDER BY s.sale_date DESC, s.id DESC';

        $this->db->query($sql);
        if ($dateFrom) $this->db->bind(':date_from', $dateFrom);
        if ($dateTo) $this->db->bind(':date_to', $dateTo);
        $sales = $this->db->resultSet();

        foreach ($sales as &$sale) {
            $this->db->query("SELECT si.*, 
                                     CASE WHEN si.viand_id IS NOT NULL THEN v.viand_name ELSE p.product_name END AS item_name,
                                     CASE WHEN si.viand_id IS NOT NULL THEN 'Viand' ELSE 'Product' END AS item_source
                              FROM sale_items si
                              LEFT JOIN viands v ON v.id = si.viand_id
                              LEFT JOIN products p ON p.id = si.product_id
                              WHERE si.sale_id = :sale_id
                              ORDER BY si.id ASC");
            $this->db->bind(':sale_id', $sale['id']);
            $sale['items'] = $this->db->resultSet();
        }

        return $sales;
    }

    public function createSale(array $header, array $items): bool
    {
        $receiptNo = 'REC-' . date('Ymd-His') . '-' . rand(100, 999);
        $saleDate = date('Y-m-d H:i:s');
        $totalAmount = 0;
        foreach ($items as $item) {
            $totalAmount += (float)$item['line_total'];
        }

        $this->db->query("INSERT INTO sales (receipt_no, sale_date, total_amount, created_by)
                          VALUES (:receipt_no, :sale_date, :total_amount, :created_by)");
        $this->db->bind(':receipt_no', $receiptNo);
        $this->db->bind(':sale_date', $saleDate);
        $this->db->bind(':total_amount', $totalAmount);
        $this->db->bind(':created_by', $header['created_by'] ?? null);
        if (!$this->db->execute()) {
            return false;
        }

        $saleId = (int)$this->db->lastInsertId();
        foreach ($items as $item) {
            $this->db->query("INSERT INTO sale_items (sale_id, viand_id, product_id, quantity, unit_price, line_total)
                              VALUES (:sale_id, :viand_id, :product_id, :quantity, :unit_price, :line_total)");
            $this->db->bind(':sale_id', $saleId);
            $this->db->bind(':viand_id', $item['viand_id']);
            $this->db->bind(':product_id', $item['product_id']);
            $this->db->bind(':quantity', $item['quantity']);
            $this->db->bind(':unit_price', $item['unit_price']);
            $this->db->bind(':line_total', $item['line_total']);
            if (!$this->db->execute()) {
                return false;
            }
        }
        return true;
    }

    public function getRevenueTrend(string $dateFrom, string $dateTo): array
    {
        $this->db->query("
            SELECT DATE(sale_date) AS trend_date, COALESCE(SUM(total_amount), 0) AS total
            FROM sales
            WHERE DATE(sale_date) BETWEEN :date_from AND :date_to
            GROUP BY DATE(sale_date)
            ORDER BY DATE(sale_date) ASC
        ");
        $this->db->bind(':date_from', $dateFrom);
        $this->db->bind(':date_to', $dateTo);
        return $this->db->resultSet();
    }

    public function getOrdersByHour(string $dateFrom, string $dateTo): array
    {
        $this->db->query("
            SELECT HOUR(sale_date) AS order_hour, COUNT(*) AS total_orders
            FROM sales
            WHERE DATE(sale_date) BETWEEN :date_from AND :date_to
            GROUP BY HOUR(sale_date)
            ORDER BY HOUR(sale_date) ASC
        ");
        $this->db->bind(':date_from', $dateFrom);
        $this->db->bind(':date_to', $dateTo);
        return $this->db->resultSet();
    }

    public function getTopSellingItems(string $dateFrom, string $dateTo, int $limit = 10): array
    {
        $limit = max(1, (int)$limit);

        $this->db->query("
            SELECT 
                CASE 
                    WHEN si.viand_id IS NOT NULL THEN CONCAT('viand-', si.viand_id)
                    ELSE CONCAT('product-', si.product_id)
                END AS row_key,
                CASE
                    WHEN si.viand_id IS NOT NULL THEN v.viand_name
                    ELSE p.product_name
                END AS item_name,
                CASE
                    WHEN si.viand_id IS NOT NULL THEN 'Viand'
                    ELSE 'Product'
                END AS item_type,
                COALESCE(SUM(si.quantity), 0) AS qty_sold,
                COALESCE(SUM(si.line_total), 0) AS revenue,
                COALESCE(AVG(si.unit_price), 0) AS avg_price,
                CASE
                    WHEN si.viand_id IS NOT NULL THEN 
                        COALESCE(AVG(si.unit_price), 0) - COALESCE((
                            SELECT SUM(vi.quantity_needed * g.latest_cost)
                            FROM viand_ingredients vi
                            INNER JOIN groceries g ON g.id = vi.grocery_id
                            WHERE vi.viand_id = si.viand_id
                        ), 0)
                    ELSE
                        COALESCE(AVG(si.unit_price), 0) - COALESCE((
                            SELECT sm.unit_cost
                            FROM stock_movements sm
                            WHERE sm.item_type = 'product'
                              AND sm.item_id = si.product_id
                              AND sm.unit_cost > 0
                            ORDER BY sm.movement_date DESC, sm.id DESC
                            LIMIT 1
                        ), 0)
                END AS profit_per_unit
            FROM sale_items si
            INNER JOIN sales s ON s.id = si.sale_id
            LEFT JOIN viands v ON v.id = si.viand_id
            LEFT JOIN products p ON p.id = si.product_id
            WHERE DATE(s.sale_date) BETWEEN :date_from AND :date_to
            GROUP BY row_key, item_name, item_type, si.viand_id, si.product_id
            ORDER BY qty_sold DESC, revenue DESC
            LIMIT {$limit}
        ");
        $this->db->bind(':date_from', $dateFrom);
        $this->db->bind(':date_to', $dateTo);

        return $this->db->resultSet();
    }
}
