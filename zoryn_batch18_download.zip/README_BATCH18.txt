ZORYN BATCH 18 INSTALLATION
===========================

This batch adds:
- Inventory usage forecasting
- Reorder suggestions
- Grocery planning values
- Supplier purchase planning links

INSTALL ORDER
-------------
1. Run: sql/batch18_inventory_forecasting.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch18.css if you want the extra styling

ROUTES ADDED
------------
/inventoryforecast/index
/inventoryforecast/updateGroceryPlanning/{id}
/inventoryforecast/saveSupplierLink

NOTES
-----
- Forecasting uses grocery usage inferred from viand ingredient consumption in completed sales.
- Reorder suggestions use either your saved planning values or fallback computed values.
- Supplier planning links let you track preferred suppliers and lead times per grocery item.
