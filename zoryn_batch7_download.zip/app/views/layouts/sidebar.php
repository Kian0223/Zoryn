<?php
$config = require CONFIG_PATH . '/config.php';
$currentUrl = $_GET['url'] ?? 'dashboard/index';

$menuItems = [
    ['label' => 'Dashboard', 'icon' => 'bi-grid-1x2-fill', 'url' => '/dashboard/index', 'match' => 'dashboard'],
    ['label' => 'Sales / POS', 'icon' => 'bi-cart-check-fill', 'url' => '/sales/index', 'match' => 'sales'],
    ['label' => 'Orders', 'icon' => 'bi-receipt-cutoff', 'url' => '/orders/index', 'match' => 'orders'],
    ['label' => 'Kitchen Display', 'icon' => 'bi-display-fill', 'url' => '/kitchen/index', 'match' => 'kitchen'],
    ['label' => 'Tables', 'icon' => 'bi-grid-3x3-gap-fill', 'url' => '/tables/index', 'match' => 'tables'],
    ['label' => 'Reservations', 'icon' => 'bi-calendar2-check-fill', 'url' => '/reservations/index', 'match' => 'reservations'],
    ['label' => 'Sales Report', 'icon' => 'bi-bar-chart-line-fill', 'url' => '/reports/index', 'match' => 'reports'],
    ['label' => 'Cashier Shifts', 'icon' => 'bi-cash-stack', 'url' => '/cashiershifts/index', 'match' => 'cashiershifts'],
    ['label' => 'Audit Trail', 'icon' => 'bi-journal-text', 'url' => '/auditlogs/index', 'match' => 'auditlogs'],
    ['label' => 'Products', 'icon' => 'bi-box-seam-fill', 'url' => '/products/index', 'match' => 'products'],
    ['label' => 'Categories', 'icon' => 'bi-tags-fill', 'url' => '/categories/index', 'match' => 'categories'],
    ['label' => 'Stock In / Out', 'icon' => 'bi-arrow-left-right', 'url' => '/stock/index', 'match' => 'stock'],
    ['label' => 'Groceries', 'icon' => 'bi-basket2-fill', 'url' => '/groceries/index', 'match' => 'groceries'],
    ['label' => 'Viands', 'icon' => 'bi-egg-fried', 'url' => '/viands/index', 'match' => 'viands'],
    ['label' => 'Users', 'icon' => 'bi-people-fill', 'url' => '/users/index', 'match' => 'users'],
];
?>
<aside class="zoryn-sidebar">
    <div class="zoryn-sidebar-inner">
        <div class="zoryn-brand-block">
            <div class="zoryn-brand-mark">Z</div>
            <div>
                <div class="zoryn-brand-name">Zoryn Restaurant</div>
                <div class="zoryn-brand-tag">Black &amp; Gold Admin</div>
            </div>
        </div>

        <div class="zoryn-panel-label">Main Menu</div>

        <nav class="nav flex-column zoryn-nav">
            <?php foreach ($menuItems as $item): ?>
                <?php $isActive = str_starts_with($currentUrl, $item['match']); ?>
                <a class="zoryn-nav-link <?= $isActive ? 'active' : ''; ?>" href="<?= $config['base_url'] . $item['url']; ?>">
                    <span class="zoryn-nav-icon"><i class="bi <?= $item['icon']; ?>"></i></span>
                    <span><?= htmlspecialchars($item['label']); ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="zoryn-sidebar-bottom">
            <div class="zoryn-user-card">
                <div class="zoryn-user-avatar">
                    <?= htmlspecialchars(strtoupper(substr($_SESSION['user']['full_name'] ?? 'U', 0, 1))); ?>
                </div>
                <div>
                    <div class="zoryn-user-name"><?= htmlspecialchars($_SESSION['user']['full_name'] ?? 'User'); ?></div>
                    <div class="zoryn-user-role"><?= htmlspecialchars($_SESSION['user']['role'] ?? 'Staff'); ?></div>
                </div>
            </div>
            <a class="zoryn-logout-link" href="<?= $config['base_url']; ?>/auth/logout">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
</aside>
