ZORYN BATCH 11 INSTALLATION
===========================

This batch adds:
- Business analytics dashboard
- Monthly sales / expenses / profit chart
- Top suppliers analytics
- Top expense category analytics
- Sales by payment method chart

INSTALL ORDER
-------------
1. No required SQL change for this batch
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch11.css if you want the extra styling

ROUTES ADDED
------------
/analytics/index

NOTES
-----
- Uses Chart.js from CDN for charts.
- Profit is computed as completed sales minus recorded expenses.
- Supplier analytics are based on received grocery purchases.
