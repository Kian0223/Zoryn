-- Zoryn Restaurant Batch 3
-- Reservations + table assignment workflow

CREATE TABLE IF NOT EXISTS reservations (
  id INT(11) NOT NULL AUTO_INCREMENT,
  reservation_no VARCHAR(50) NOT NULL,
  customer_name VARCHAR(150) NOT NULL,
  customer_phone VARCHAR(50) DEFAULT NULL,
  customer_email VARCHAR(150) DEFAULT NULL,
  pax_count INT(11) NOT NULL DEFAULT 1,
  reservation_date DATE NOT NULL,
  reservation_time TIME NOT NULL,
  table_id INT(11) DEFAULT NULL,
  status ENUM('pending','confirmed','seated','completed','cancelled','no_show') NOT NULL DEFAULT 'pending',
  notes TEXT DEFAULT NULL,
  created_by INT(11) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  updated_at DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_reservation_no (reservation_no),
  KEY fk_reservations_table (table_id),
  KEY fk_reservations_user (created_by),
  KEY idx_reservations_date_time (reservation_date, reservation_time),
  CONSTRAINT fk_reservations_table FOREIGN KEY (table_id) REFERENCES dining_tables (id) ON DELETE SET NULL,
  CONSTRAINT fk_reservations_user FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
