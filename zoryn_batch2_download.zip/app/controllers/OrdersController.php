<?php
class OrdersController extends Controller
{
    public function index(): void
    {
        $this->requireLogin();

        $orderModel = $this->model('Order');
        $tableModel = $this->model('DiningTable');
        $productModel = $this->model('Product');
        $viandModel = $this->model('Viand');

        $this->view('orders/index', [
            'title' => 'Orders',
            'orders' => $orderModel->getAllWithItems(),
            'tables' => $tableModel->getAll(),
            'products' => $productModel->getAll(),
            'viands' => $viandModel->getAllWithCost(),
            'counts' => $orderModel->getCounts(),
        ]);
    }

    public function store(): void
    {
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('orders/index');
            return;
        }

        $orderType = trim($_POST['order_type'] ?? 'dine_in');
        $tableId = (int)($_POST['table_id'] ?? 0);
        $customerName = trim($_POST['customer_name'] ?? '');
        $customerPhone = trim($_POST['customer_phone'] ?? '');
        $notes = trim($_POST['notes'] ?? '');

        $productIds = $_POST['product_id'] ?? [];
        $viandIds = $_POST['viand_id'] ?? [];
        $quantities = $_POST['quantity'] ?? [];
        $unitPrices = $_POST['unit_price'] ?? [];
        $types = $_POST['item_type'] ?? [];
        $itemNotes = $_POST['item_notes'] ?? [];

        if ($orderType === 'dine_in' && $tableId <= 0) {
            $_SESSION['error'] = 'Please select a table for dine-in orders.';
            $this->redirect('orders/index');
            return;
        }

        $items = [];
        foreach ($types as $i => $type) {
            $qty = (float)($quantities[$i] ?? 0);
            $price = (float)($unitPrices[$i] ?? 0);

            if ($qty <= 0 || $price < 0) {
                continue;
            }

            $productId = !empty($productIds[$i]) ? (int)$productIds[$i] : null;
            $viandId = !empty($viandIds[$i]) ? (int)$viandIds[$i] : null;

            if ($type === 'product' && !$productId) {
                continue;
            }

            if ($type === 'viand' && !$viandId) {
                continue;
            }

            $items[] = [
                'product_id' => $type === 'product' ? $productId : null,
                'viand_id' => $type === 'viand' ? $viandId : null,
                'quantity' => $qty,
                'unit_price' => $price,
                'line_total' => $qty * $price,
                'notes' => trim($itemNotes[$i] ?? ''),
            ];
        }

        if (empty($items)) {
            $_SESSION['error'] = 'Please add at least one order item.';
            $this->redirect('orders/index');
            return;
        }

        $orderModel = $this->model('Order');
        $orderId = $orderModel->createOrder([
            'order_type' => $orderType,
            'table_id' => $tableId > 0 ? $tableId : null,
            'customer_name' => $customerName,
            'customer_phone' => $customerPhone,
            'notes' => $notes,
            'created_by' => $_SESSION['user']['id'] ?? null,
        ], $items);

        if (!$orderId) {
            $_SESSION['error'] = 'Failed to create order.';
            $this->redirect('orders/index');
            return;
        }

        if ($orderType === 'dine_in' && $tableId > 0) {
            $tableModel = $this->model('DiningTable');
            $tableModel->setStatus($tableId, 'occupied');
        }

        $_SESSION['success'] = 'Order created successfully.';
        $this->redirect('orders/index');
    }

    public function updateStatus($id): void
    {
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('orders/index');
            return;
        }

        $orderId = (int)$id;
        $status = trim($_POST['status'] ?? '');

        $orderModel = $this->model('Order');
        $tableModel = $this->model('DiningTable');

        $order = $orderModel->findById($orderId);
        if (!$order) {
            $_SESSION['error'] = 'Order not found.';
            $this->redirect('orders/index');
            return;
        }

        if (!$orderModel->updateStatus($orderId, $status)) {
            $_SESSION['error'] = 'Failed to update order status.';
            $this->redirect('orders/index');
            return;
        }

        if (!empty($order['table_id'])) {
            if (in_array($status, ['pending', 'preparing', 'ready', 'served'], true)) {
                $tableModel->setStatus((int)$order['table_id'], 'occupied');
            } elseif (in_array($status, ['completed', 'cancelled'], true)) {
                $tableModel->setStatus((int)$order['table_id'], 'available');
            }
        }

        $_SESSION['success'] = 'Order status updated successfully.';
        $this->redirect('orders/index');
    }
}
