ZORYN BATCH 19 INSTALLATION
===========================

This batch adds:
- Purchase plan generation from reorder list
- Approval workflow for purchase plans
- Supplier quotation entry and comparison

INSTALL ORDER
-------------
1. Run: sql/batch19_purchase_planning.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch19.css if you want the extra styling

ROUTES ADDED
------------
/purchaseplans/index
/purchaseplans/createFromReorder
/purchaseplans/updateItem/{itemId}
/purchaseplans/submit/{planId}
/purchaseplans/approve/{planId}
/purchaseplans/reject/{planId}
/supplierquotations/store

NOTES
-----
- Purchase plans are created from current reorder suggestions.
- Plan items can be edited before submission and approval.
- Supplier quotation comparison highlights the cheapest/best-ranked quote per grocery item.
