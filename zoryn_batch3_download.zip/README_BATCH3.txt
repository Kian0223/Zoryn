ZORYN BATCH 3 INSTALLATION
==========================

This batch adds:
- Reservations page
- Reservation table assignment
- Reservation status flow
- Sidebar link for Reservations

INSTALL ORDER
-------------
1. Run: sql/batch3_reservations.sql
2. Copy the PHP files into your project folders
3. Optional: merge public/assets/css/batch3.css into your main style.css

ROUTES ADDED
------------
/reservations/index
/reservations/store
/reservations/update/{id}
/reservations/updateStatus/{id}
/reservations/delete/{id}

STATUS LOGIC
------------
- confirmed  -> table becomes reserved
- seated     -> table becomes occupied
- completed  -> table becomes available
- cancelled  -> table becomes available
- no_show    -> table becomes available

NOTES
-----
- This batch is designed to work with Batch 2 tables/orders.
- It does not auto-convert a reservation into an order yet.
- That can be added in a future batch.
