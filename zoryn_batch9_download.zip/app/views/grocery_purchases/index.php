<?php require APP_PATH . '/views/layouts/header.php'; ?>
<div class="d-flex">
<?php require APP_PATH . '/views/layouts/sidebar.php'; ?>
<main class="content-area flex-grow-1 p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">Grocery Receiving</h2>
    </div>

    <?php require APP_PATH . '/views/partials/alerts.php'; ?>

    <div class="row g-4 mb-4">
        <div class="col-md-3"><div class="card shadow-sm border-0 h-100"><div class="card-body"><div class="text-muted small">Total Purchases</div><h3 class="mb-0"><?= (int)($summary['total_purchases'] ?? 0); ?></h3></div></div></div>
        <div class="col-md-3"><div class="card shadow-sm border-0 h-100"><div class="card-body"><div class="text-muted small">Draft</div><h3 class="mb-0 text-warning"><?= (int)($summary['draft_purchases'] ?? 0); ?></h3></div></div></div>
        <div class="col-md-3"><div class="card shadow-sm border-0 h-100"><div class="card-body"><div class="text-muted small">Received</div><h3 class="mb-0 text-success"><?= (int)($summary['received_purchases'] ?? 0); ?></h3></div></div></div>
        <div class="col-md-3"><div class="card shadow-sm border-0 h-100"><div class="card-body"><div class="text-muted small">Balance Due</div><h3 class="mb-0">₱<?= number_format((float)($summary['total_balance_due'] ?? 0), 2); ?></h3></div></div></div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Purchase No</th>
                        <th>Supplier</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Paid</th>
                        <th>Balance</th>
                        <th>Payment Status</th>
                        <th width="220">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (($purchases ?? []) as $purchase): ?>
                        <tr>
                            <td><?= htmlspecialchars($purchase['purchase_no']); ?></td>
                            <td><?= htmlspecialchars($purchase['supplier_name'] ?? '-'); ?></td>
                            <td><?= htmlspecialchars($purchase['purchase_date']); ?></td>
                            <td><span class="badge text-bg-<?= ($purchase['status'] === 'received') ? 'success' : (($purchase['status'] === 'cancelled') ? 'danger' : 'warning'); ?>"><?= strtoupper(htmlspecialchars($purchase['status'])); ?></span></td>
                            <td>₱<?= number_format((float)$purchase['total_amount'], 2); ?></td>
                            <td>₱<?= number_format((float)($purchase['amount_paid'] ?? 0), 2); ?></td>
                            <td>₱<?= number_format((float)($purchase['balance_due'] ?? 0), 2); ?></td>
                            <td><span class="badge text-bg-<?= ($purchase['payment_status'] === 'paid') ? 'success' : (($purchase['payment_status'] === 'partial') ? 'warning' : 'secondary'); ?>"><?= strtoupper(htmlspecialchars($purchase['payment_status'] ?? 'unpaid')); ?></span></td>
                            <td>
                                <?php if (($purchase['status'] ?? '') === 'draft'): ?>
                                    <a class="btn btn-success btn-sm" onclick="return confirm('Receive this purchase and add stock?')" href="<?= $config['base_url']; ?>/grocerypurchases/receive/<?= (int)$purchase['id']; ?>">Receive</a>
                                    <a class="btn btn-danger btn-sm" onclick="return confirm('Cancel this draft purchase?')" href="<?= $config['base_url']; ?>/grocerypurchases/cancel/<?= (int)$purchase['id']; ?>">Cancel</a>
                                <?php else: ?>
                                    <span class="text-muted small">No actions</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($purchases)): ?>
                        <tr><td colspan="9" class="text-center text-muted">No grocery purchases found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
</div>
<?php require APP_PATH . '/views/layouts/footer.php'; ?>
