<?php
class Grocery extends Model
{
    public function getAll(): array
    {
        $this->db->query("
            SELECT *,
                   CASE
                       WHEN current_stock <= 0 THEN 'out'
                       WHEN current_stock <= low_stock_threshold THEN 'low'
                       ELSE 'ok'
                   END AS stock_status
            FROM groceries
            ORDER BY
                CASE
                    WHEN current_stock <= 0 THEN 0
                    WHEN current_stock <= low_stock_threshold THEN 1
                    ELSE 2
                END,
                grocery_name ASC
        ");
        return $this->db->resultSet();
    }

    public function getLowStockCount(): int
    {
        $this->db->query("
            SELECT COUNT(*) AS total
            FROM groceries
            WHERE current_stock <= low_stock_threshold
        ");
        $row = $this->db->single();
        return (int)($row['total'] ?? 0);
    }

    public function getOutOfStockCount(): int
    {
        $this->db->query("
            SELECT COUNT(*) AS total
            FROM groceries
            WHERE current_stock <= 0
        ");
        $row = $this->db->single();
        return (int)($row['total'] ?? 0);
    }

    public function getLowStockItems(): array
    {
        $this->db->query("
            SELECT *
            FROM groceries
            WHERE current_stock <= low_stock_threshold
            ORDER BY current_stock ASC, grocery_name ASC
        ");
        return $this->db->resultSet();
    }

    public function getInventoryItems(): array
    {
        $this->db->query("
            SELECT 
                id,
                'grocery' AS item_type,
                grocery_name AS item_name,
                'Groceries' AS category_name,
                current_stock,
                low_stock_threshold,
                unit,
                latest_cost AS cost_price,
                NULL AS supplier_name,
                CASE
                    WHEN current_stock <= 0 THEN 'out'
                    WHEN current_stock <= low_stock_threshold THEN 'low'
                    ELSE 'ok'
                END AS stock_status
            FROM groceries
            ORDER BY grocery_name ASC
        ");
        return $this->db->resultSet();
    }

    public function create(array $data): bool
    {
        $this->db->query("
            INSERT INTO groceries (
                grocery_name,
                unit,
                current_stock,
                low_stock_threshold,
                package_quantity,
                package_cost,
                latest_cost
            ) VALUES (
                :grocery_name,
                :unit,
                :current_stock,
                :low_stock_threshold,
                :package_quantity,
                :package_cost,
                :latest_cost
            )
        ");

        $this->db->bind(':grocery_name', $data['grocery_name']);
        $this->db->bind(':unit', $data['unit']);
        $this->db->bind(':current_stock', $data['current_stock']);
        $this->db->bind(':low_stock_threshold', $data['low_stock_threshold']);
        $this->db->bind(':package_quantity', $data['package_quantity']);
        $this->db->bind(':package_cost', $data['package_cost']);
        $this->db->bind(':latest_cost', $data['latest_cost']);

        return $this->db->execute();
    }

    public function findById(int $id): array|false
    {
        $this->db->query("SELECT * FROM groceries WHERE id = :id LIMIT 1");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    public function update(int $id, array $data): bool
    {
        $this->db->query("
            UPDATE groceries
            SET grocery_name = :grocery_name,
                unit = :unit,
                current_stock = :current_stock,
                low_stock_threshold = :low_stock_threshold,
                package_quantity = :package_quantity,
                package_cost = :package_cost,
                latest_cost = :latest_cost
            WHERE id = :id
        ");

        $this->db->bind(':grocery_name', $data['grocery_name']);
        $this->db->bind(':unit', $data['unit']);
        $this->db->bind(':current_stock', $data['current_stock']);
        $this->db->bind(':low_stock_threshold', $data['low_stock_threshold']);
        $this->db->bind(':package_quantity', $data['package_quantity']);
        $this->db->bind(':package_cost', $data['package_cost']);
        $this->db->bind(':latest_cost', $data['latest_cost']);
        $this->db->bind(':id', $id);

        return $this->db->execute();
    }

    public function adjustStock(int $id, float $quantity): bool
    {
        $this->db->query("UPDATE groceries SET current_stock = current_stock + :quantity WHERE id = :id");
        $this->db->bind(':quantity', $quantity);
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function delete(int $id): bool
    {
        $this->db->query("DELETE FROM groceries WHERE id = :id");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }
}
