ALTER TABLE orders
  ADD COLUMN cancellation_reason VARCHAR(255) DEFAULT NULL AFTER updated_at;

CREATE TABLE IF NOT EXISTS audit_logs (
  id INT(11) NOT NULL AUTO_INCREMENT,
  module_name VARCHAR(100) NOT NULL,
  action_type VARCHAR(100) NOT NULL,
  reference_id INT(11) DEFAULT NULL,
  description VARCHAR(255) DEFAULT NULL,
  created_by INT(11) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS cashier_shifts (
  id INT(11) NOT NULL AUTO_INCREMENT,
  user_id INT(11) NOT NULL,
  shift_date DATE NOT NULL,
  opening_cash DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  closing_cash DECIMAL(12,2) DEFAULT NULL,
  expected_cash DECIMAL(12,2) DEFAULT NULL,
  cash_difference DECIMAL(12,2) DEFAULT NULL,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  opened_at DATETIME NOT NULL DEFAULT current_timestamp(),
  closed_at DATETIME DEFAULT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
