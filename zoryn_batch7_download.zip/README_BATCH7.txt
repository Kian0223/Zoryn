ZORYN BATCH 7 INSTALLATION
==========================

This batch adds:
- Inventory restock on VOID sales
- Cashier shifts page
- Audit trail page
- Audit logging for void/refund and shifts

INSTALL ORDER
-------------
1. Run: sql/batch7_audit_shifts_restock.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch7.css if you want the extra styling

ROUTES ADDED
------------
/cashiershifts/index
/cashiershifts/open
/cashiershifts/close/{id}
/auditlogs/index

NOTES
-----
- VOID now restores product and grocery stock.
- REFUND is logged financially but does not restock inventory.
- Cashier shifts use today's completed cash sales as expected cash basis.
