<?php
class Sale extends Model
{
    public function getTodaySalesAmount(): float
    {
        $this->db->query("SELECT COALESCE(SUM(CASE WHEN sale_status='completed' THEN total_amount ELSE 0 END), 0) AS total FROM sales WHERE DATE(sale_date) = CURDATE()");
        $row = $this->db->single();
        return (float)($row['total'] ?? 0);
    }

    public function getTotalSalesCount(): int
    {
        $this->db->query("SELECT COUNT(*) AS total FROM sales");
        $row = $this->db->single();
        return (int)($row['total'] ?? 0);
    }

    public function getRangeSummary(?string $dateFrom = null, ?string $dateTo = null): array
    {
        $where = [];
        if ($dateFrom) $where[] = "DATE(sale_date) >= :date_from";
        if ($dateTo) $where[] = "DATE(sale_date) <= :date_to";
        $sql = "SELECT COUNT(*) AS total_receipts, COALESCE(SUM(CASE WHEN sale_status='completed' THEN total_amount ELSE 0 END),0) AS total_sales FROM sales";
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
        $this->db->query($sql);
        if ($dateFrom) $this->db->bind(':date_from', $dateFrom);
        if ($dateTo) $this->db->bind(':date_to', $dateTo);
        $row = $this->db->single() ?: [];
        return ['total_receipts'=>(int)($row['total_receipts'] ?? 0),'total_sales'=>(float)($row['total_sales'] ?? 0)];
    }

    public function getSalesWithItems(?string $dateFrom = null, ?string $dateTo = null): array
    {
        $where = [];
        if ($dateFrom) $where[] = "DATE(s.sale_date) >= :date_from";
        if ($dateTo) $where[] = "DATE(s.sale_date) <= :date_to";
        $sql = "SELECT s.*, u.full_name AS cashier_name FROM sales s LEFT JOIN users u ON u.id = s.created_by";
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
        $sql .= ' ORDER BY s.sale_date DESC, s.id DESC';
        $this->db->query($sql);
        if ($dateFrom) $this->db->bind(':date_from', $dateFrom);
        if ($dateTo) $this->db->bind(':date_to', $dateTo);
        $sales = $this->db->resultSet();
        foreach ($sales as &$sale) {
            $this->db->query("SELECT si.*, CASE WHEN si.viand_id IS NOT NULL THEN v.viand_name ELSE p.product_name END AS item_name,
                                     CASE WHEN si.viand_id IS NOT NULL THEN 'Viand' ELSE 'Product' END AS item_source
                              FROM sale_items si
                              LEFT JOIN viands v ON v.id = si.viand_id
                              LEFT JOIN products p ON p.id = si.product_id
                              WHERE si.sale_id = :sale_id ORDER BY si.id ASC");
            $this->db->bind(':sale_id', $sale['id']);
            $sale['items'] = $this->db->resultSet();
        }
        return $sales;
    }

    public function findByIdWithItems(int $saleId): array|false
    {
        $this->db->query("SELECT s.*, u.full_name AS cashier_name FROM sales s LEFT JOIN users u ON u.id = s.created_by WHERE s.id = :sale_id LIMIT 1");
        $this->db->bind(':sale_id', $saleId);
        $sale = $this->db->single();
        if (!$sale) return false;
        $this->db->query("SELECT si.*, CASE WHEN si.viand_id IS NOT NULL THEN v.viand_name ELSE p.product_name END AS item_name,
                                 CASE WHEN si.viand_id IS NOT NULL THEN 'Viand' ELSE 'Product' END AS item_source
                          FROM sale_items si
                          LEFT JOIN viands v ON v.id = si.viand_id
                          LEFT JOIN products p ON p.id = si.product_id
                          WHERE si.sale_id = :sale_id ORDER BY si.id ASC");
        $this->db->bind(':sale_id', $saleId);
        $sale['items'] = $this->db->resultSet();
        return $sale;
    }

    public function markVoided(int $saleId, ?string $reason): bool
    {
        $this->db->query("UPDATE sales SET sale_status='voided', void_reason=:reason WHERE id=:id");
        $this->db->bind(':reason', $reason ?: null);
        $this->db->bind(':id', $saleId);
        return $this->db->execute();
    }

    public function markRefunded(int $saleId, ?string $reason, float $amount): bool
    {
        $this->db->query("UPDATE sales SET sale_status='refunded', void_reason=:reason, refunded_amount=:amount WHERE id=:id");
        $this->db->bind(':reason', $reason ?: null);
        $this->db->bind(':amount', $amount);
        $this->db->bind(':id', $saleId);
        return $this->db->execute();
    }
}
