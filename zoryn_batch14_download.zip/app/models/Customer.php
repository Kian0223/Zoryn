<?php
class Customer extends Model
{
    public function getAll(): array
    {
        $this->db->query("SELECT * FROM customers ORDER BY full_name ASC");
        return $this->db->resultSet();
    }

    public function findById(int $id): array|false
    {
        $this->db->query("SELECT * FROM customers WHERE id = :id LIMIT 1");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    public function getBirthdayCustomersThisMonth(): array
    {
        $this->db->query("
            SELECT *
            FROM customers
            WHERE birthdate IS NOT NULL
              AND MONTH(birthdate) = MONTH(CURDATE())
            ORDER BY DAY(birthdate) ASC, full_name ASC
        ");
        return $this->db->resultSet();
    }

    public function getSmsExportRows(): array
    {
        $this->db->query("
            SELECT customer_code, full_name, phone, email, total_points, total_spent, visit_count,
                   DATE_FORMAT(birthdate, '%Y-%m-%d') AS birthdate
            FROM customers
            WHERE phone IS NOT NULL AND phone <> ''
            ORDER BY full_name ASC
        ");
        return $this->db->resultSet();
    }
}
