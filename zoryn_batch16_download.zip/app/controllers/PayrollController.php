<?php
class PayrollController extends Controller
{
    public function index(): void
    {
        $this->requireLogin();
        $employeeModel = $this->model('Employee');
        $adjustmentModel = $this->model('PayrollAdjustment');

        $dateFrom = trim($_GET['date_from'] ?? date('Y-m-01'));
        $dateTo = trim($_GET['date_to'] ?? date('Y-m-d'));

        $rows = $employeeModel->getPayrollSummary($dateFrom, $dateTo);
        $adjRows = $adjustmentModel->getSummaryByEmployee($dateFrom, $dateTo);
        $adjMap = [];
        foreach ($adjRows as $adj) {
            $adjMap[(int)$adj['employee_id']] = $adj;
        }

        foreach ($rows as &$row) {
            $empId = (int)$row['id'];
            $allowances = (float)($adjMap[$empId]['total_allowances'] ?? 0);
            $deductions = (float)($adjMap[$empId]['total_deductions'] ?? 0);
            $row['total_allowances'] = $allowances;
            $row['total_deductions'] = $deductions;
            $row['gross_pay'] = (float)$row['base_gross_pay'] + $allowances;
            $row['net_pay'] = $row['gross_pay'] - $deductions;
        }

        $this->view('payroll/index', [
            'title' => 'Payroll Summary',
            'rows' => $rows,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
        ]);
    }
}
