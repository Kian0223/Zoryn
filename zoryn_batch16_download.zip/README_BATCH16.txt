ZORYN BATCH 16 INSTALLATION
===========================

This batch adds:
- Leave requests
- Payroll allowances and deductions
- Permission middleware helper
- Net-pay payroll summary

INSTALL ORDER
-------------
1. Run: sql/batch16_permissions_leave_payroll.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch16.css if you want the extra styling

ROUTES ADDED
------------
/leaves/index
/leaves/store
/leaves/approve/{id}
/leaves/reject/{id}
/payrolladjustments/index
/payrolladjustments/store

NOTES
-----
- PermissionMiddleware helper is included, but controllers must call it explicitly to enforce route/page access.
- Net pay = base gross pay + allowances - deductions.
- Leave requests are tracked separately from attendance in this batch.
