-- Zoryn Restaurant Batch 5
-- Kitchen dashboard + payment tracking + bill preview

ALTER TABLE sales
  ADD COLUMN payment_method ENUM('cash','gcash','card','bank_transfer') NOT NULL DEFAULT 'cash' AFTER total_amount,
  ADD COLUMN payment_reference VARCHAR(100) DEFAULT NULL AFTER payment_method,
  ADD COLUMN paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER payment_reference,
  ADD COLUMN change_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER paid_amount;
