CREATE TABLE IF NOT EXISTS purchase_plans (
  id INT(11) NOT NULL AUTO_INCREMENT,
  plan_no VARCHAR(50) NOT NULL,
  plan_date DATE NOT NULL,
  status ENUM('draft','submitted','approved','rejected','converted') NOT NULL DEFAULT 'draft',
  notes VARCHAR(255) DEFAULT NULL,
  created_by INT(11) DEFAULT NULL,
  approved_by INT(11) DEFAULT NULL,
  approved_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uq_purchase_plan_no (plan_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS purchase_plan_items (
  id INT(11) NOT NULL AUTO_INCREMENT,
  plan_id INT(11) NOT NULL,
  grocery_id INT(11) NOT NULL,
  suggested_qty DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  approved_qty DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  estimated_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  supplier_id INT(11) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS supplier_quotations (
  id INT(11) NOT NULL AUTO_INCREMENT,
  grocery_id INT(11) NOT NULL,
  supplier_id INT(11) NOT NULL,
  quoted_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  lead_time_days INT(11) NOT NULL DEFAULT 0,
  min_order_qty DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  quote_date DATE NOT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
