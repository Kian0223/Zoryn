ZORYN BATCH 17 INSTALLATION
===========================

This batch adds:
- Permission-enforced HR controllers
- Printable payslips
- HR dashboard with attendance and leave analytics

INSTALL ORDER
-------------
1. No required SQL change for this batch
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch17.css if you want the extra styling

ROUTES ADDED / UPDATED
----------------------
/hrdashboard/index
/payroll/payslip/{employeeId}

NOTES
-----
- BaseControllerWithPermissions adds a reusable permission check helper for controllers.
- This batch enforces permissions on HR controllers using module keys like:
  employees, attendance, leaves, payroll, hr_dashboard
- Admin role_id = 1 bypasses permission checks.
- Payslip view is print-friendly and opens in a separate page.
