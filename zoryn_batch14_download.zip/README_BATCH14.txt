ZORYN BATCH 14 INSTALLATION
===========================

This batch adds:
- Promo codes
- Promo redemption logging
- Birthday rewards page
- SMS-ready customer export
- Checkout promo code support

INSTALL ORDER
-------------
1. Run: sql/batch14_promos_birthdays_sms.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch14.css if you want the extra styling

ROUTES ADDED
------------
/promos/index
/promos/store
/promos/update/{id}
/promos/delete/{id}
/birthdayrewards/index
/customerexport/sms

NOTES
-----
- Promo discount is applied together with loyalty redemption.
- Promo code support is added to the checkout modal.
- Birthday Rewards shows customers with birthdays in the current month.
- SMS export downloads a CSV of customers with phone numbers.
