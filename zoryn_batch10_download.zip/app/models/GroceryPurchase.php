<?php
class GroceryPurchase extends Model
{
    public function getAll(): array
    {
        $this->db->query("
            SELECT gp.*, s.supplier_name, u.full_name,
                   CASE
                       WHEN gp.status <> 'received' THEN 'not_received'
                       WHEN gp.balance_due <= 0 THEN 'paid'
                       WHEN gp.due_date IS NULL THEN 'no_due_date'
                       WHEN gp.due_date < CURDATE() THEN 'overdue'
                       WHEN gp.due_date = CURDATE() THEN 'due_today'
                       ELSE 'upcoming'
                   END AS due_status
            FROM grocery_purchases gp
            LEFT JOIN suppliers s ON s.id = gp.supplier_id
            LEFT JOIN users u ON u.id = gp.created_by
            ORDER BY gp.id DESC
        ");
        $rows = $this->db->resultSet();
        foreach ($rows as &$row) {
            $row['items'] = $this->getItems((int)$row['id']);
        }
        return $rows;
    }

    public function getItems(int $purchaseId): array
    {
        $this->db->query("
            SELECT gpi.*, g.grocery_name, g.unit
            FROM grocery_purchase_items gpi
            LEFT JOIN groceries g ON g.id = gpi.grocery_id
            WHERE gpi.purchase_id = :purchase_id
            ORDER BY gpi.id ASC
        ");
        $this->db->bind(':purchase_id', $purchaseId);
        return $this->db->resultSet();
    }

    public function findById(int $id): array|false
    {
        $this->db->query("
            SELECT gp.*, s.supplier_name
            FROM grocery_purchases gp
            LEFT JOIN suppliers s ON s.id = gp.supplier_id
            WHERE gp.id = :id
            LIMIT 1
        ");
        $this->db->bind(':id', $id);
        $row = $this->db->single();
        if (!$row) return false;
        $row['items'] = $this->getItems($id);
        return $row;
    }

    public function create(array $header, array $items): int|false
    {
        $purchaseNo = 'GP-' . date('Ymd-His') . '-' . rand(100, 999);
        $totalAmount = 0;
        foreach ($items as $item) $totalAmount += (float)$item['line_total'];

        $this->db->query("
            INSERT INTO grocery_purchases (
                purchase_no, supplier_id, purchase_date, due_date, status, total_amount,
                amount_paid, balance_due, payment_status, expense_posted, notes, created_by, created_at
            ) VALUES (
                :purchase_no, :supplier_id, :purchase_date, :due_date, :status, :total_amount,
                0, :balance_due, 'unpaid', 0, :notes, :created_by, NOW()
            )
        ");
        $this->db->bind(':purchase_no', $purchaseNo);
        $this->db->bind(':supplier_id', $header['supplier_id'] ?: null);
        $this->db->bind(':purchase_date', $header['purchase_date']);
        $this->db->bind(':due_date', $header['due_date'] ?: null);
        $this->db->bind(':status', $header['status'] ?? 'draft');
        $this->db->bind(':total_amount', $totalAmount);
        $this->db->bind(':balance_due', $totalAmount);
        $this->db->bind(':notes', $header['notes'] ?: null);
        $this->db->bind(':created_by', $header['created_by'] ?? null);

        if (!$this->db->execute()) return false;
        $purchaseId = (int)$this->db->lastInsertId();

        foreach ($items as $item) {
            $this->db->query("
                INSERT INTO grocery_purchase_items (
                    purchase_id, grocery_id, package_count, package_quantity, package_cost, total_quantity, line_total
                ) VALUES (
                    :purchase_id, :grocery_id, :package_count, :package_quantity, :package_cost, :total_quantity, :line_total
                )
            ");
            $this->db->bind(':purchase_id', $purchaseId);
            $this->db->bind(':grocery_id', $item['grocery_id']);
            $this->db->bind(':package_count', $item['package_count']);
            $this->db->bind(':package_quantity', $item['package_quantity']);
            $this->db->bind(':package_cost', $item['package_cost']);
            $this->db->bind(':total_quantity', $item['total_quantity']);
            $this->db->bind(':line_total', $item['line_total']);
            if (!$this->db->execute()) return false;
        }

        return $purchaseId;
    }

    public function markReceived(int $id): bool
    {
        $this->db->query("
            UPDATE grocery_purchases
            SET status = 'received', received_at = NOW()
            WHERE id = :id AND status = 'draft'
        ");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function markCancelled(int $id): bool
    {
        $this->db->query("
            UPDATE grocery_purchases
            SET status = 'cancelled'
            WHERE id = :id AND status = 'draft'
        ");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function applyPayment(int $id, float $amount): bool
    {
        $purchase = $this->findById($id);
        if (!$purchase) return false;

        $amountPaid = (float)($purchase['amount_paid'] ?? 0) + $amount;
        $totalAmount = (float)($purchase['total_amount'] ?? 0);
        $balanceDue = max(0, $totalAmount - $amountPaid);

        $paymentStatus = 'unpaid';
        if ($amountPaid > 0 && $balanceDue > 0) $paymentStatus = 'partial';
        if ($balanceDue <= 0) $paymentStatus = 'paid';

        $this->db->query("
            UPDATE grocery_purchases
            SET amount_paid = :amount_paid,
                balance_due = :balance_due,
                payment_status = :payment_status
            WHERE id = :id
        ");
        $this->db->bind(':amount_paid', $amountPaid);
        $this->db->bind(':balance_due', $balanceDue);
        $this->db->bind(':payment_status', $paymentStatus);
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function markExpensePosted(int $id): bool
    {
        $this->db->query("UPDATE grocery_purchases SET expense_posted = 1 WHERE id = :id");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function getSummary(): array
    {
        $this->db->query("
            SELECT
                COUNT(*) AS total_purchases,
                SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) AS draft_purchases,
                SUM(CASE WHEN status = 'received' THEN 1 ELSE 0 END) AS received_purchases,
                COALESCE(SUM(CASE WHEN status = 'received' THEN total_amount ELSE 0 END), 0) AS received_total,
                COALESCE(SUM(CASE WHEN status = 'received' THEN balance_due ELSE 0 END), 0) AS total_balance_due,
                COALESCE(SUM(CASE WHEN status = 'received' AND balance_due > 0 AND due_date < CURDATE() THEN balance_due ELSE 0 END), 0) AS overdue_balance
            FROM grocery_purchases
        ");
        return $this->db->single() ?: [
            'total_purchases' => 0,
            'draft_purchases' => 0,
            'received_purchases' => 0,
            'received_total' => 0,
            'total_balance_due' => 0,
            'overdue_balance' => 0,
        ];
    }

    public function getAgingBuckets(): array
    {
        $this->db->query("
            SELECT
                COALESCE(SUM(CASE WHEN status='received' AND balance_due > 0 AND due_date >= CURDATE() THEN balance_due ELSE 0 END), 0) AS current_bucket,
                COALESCE(SUM(CASE WHEN status='received' AND balance_due > 0 AND DATEDIFF(CURDATE(), due_date) BETWEEN 1 AND 30 THEN balance_due ELSE 0 END), 0) AS bucket_1_30,
                COALESCE(SUM(CASE WHEN status='received' AND balance_due > 0 AND DATEDIFF(CURDATE(), due_date) BETWEEN 31 AND 60 THEN balance_due ELSE 0 END), 0) AS bucket_31_60,
                COALESCE(SUM(CASE WHEN status='received' AND balance_due > 0 AND DATEDIFF(CURDATE(), due_date) BETWEEN 61 AND 90 THEN balance_due ELSE 0 END), 0) AS bucket_61_90,
                COALESCE(SUM(CASE WHEN status='received' AND balance_due > 0 AND DATEDIFF(CURDATE(), due_date) > 90 THEN balance_due ELSE 0 END), 0) AS bucket_90_plus
            FROM grocery_purchases
        ");
        return $this->db->single() ?: [
            'current_bucket' => 0,
            'bucket_1_30' => 0,
            'bucket_31_60' => 0,
            'bucket_61_90' => 0,
            'bucket_90_plus' => 0,
        ];
    }
}
