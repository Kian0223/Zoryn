<?php require APP_PATH . '/views/layouts/header.php'; ?>
<div class="d-flex">
    <?php require APP_PATH . '/views/layouts/sidebar.php'; ?>
    <main class="content-area flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Orders</h2>
        </div>

        <?php require APP_PATH . '/views/partials/alerts.php'; ?>

        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body">
                        <div class="text-muted small">Today Orders</div>
                        <h3 class="mb-0"><?= (int)($counts['total_orders'] ?? 0); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body">
                        <div class="text-muted small">Pending / Preparing</div>
                        <h3 class="mb-0 text-warning"><?= (int)($counts['pending_orders'] ?? 0) + (int)($counts['preparing_orders'] ?? 0); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body">
                        <div class="text-muted small">Ready Orders</div>
                        <h3 class="mb-0 text-success"><?= (int)($counts['ready_orders'] ?? 0); ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <h5 class="mb-3">Create Order</h5>

                <form method="POST" action="<?= $config['base_url']; ?>/orders/store">
                    <div class="row g-3 mb-3">
                        <div class="col-md-3">
                            <label class="form-label">Order Type</label>
                            <select name="order_type" id="orderType" class="form-select" onchange="toggleOrderFields()">
                                <option value="dine_in" <?= (($prefill['order_type'] ?? '') === 'dine_in') ? 'selected' : ''; ?>>Dine In</option>
                                <option value="takeout" <?= (($prefill['order_type'] ?? '') === 'takeout') ? 'selected' : ''; ?>>Takeout</option>
                                <option value="delivery" <?= (($prefill['order_type'] ?? '') === 'delivery') ? 'selected' : ''; ?>>Delivery</option>
                            </select>
                        </div>

                        <div class="col-md-3 dine-in-field">
                            <label class="form-label">Table</label>
                            <select name="table_id" class="form-select">
                                <option value="">-- Select Table --</option>
                                <?php foreach ($tables as $table): ?>
                                    <option value="<?= (int)$table['id']; ?>" <?= ((int)($prefill['table_id'] ?? 0) === (int)$table['id']) ? 'selected' : ''; ?>>
                                        <?= htmlspecialchars($table['table_name']); ?> (<?= htmlspecialchars($table['status']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-3 customer-field d-none">
                            <label class="form-label">Customer Name</label>
                            <input type="text" name="customer_name" class="form-control" value="<?= htmlspecialchars($prefill['customer_name'] ?? ''); ?>" placeholder="Optional">
                        </div>

                        <div class="col-md-3 customer-field d-none">
                            <label class="form-label">Customer Phone</label>
                            <input type="text" name="customer_phone" class="form-control" value="<?= htmlspecialchars($prefill['customer_phone'] ?? ''); ?>" placeholder="Optional">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Order Notes</label>
                            <input type="text" name="notes" class="form-control" value="<?= htmlspecialchars($prefill['notes'] ?? ''); ?>" placeholder="Optional note">
                        </div>
                    </div>

                    <div id="order-items-wrapper">
                        <div class="row g-2 order-row mb-2">
                            <div class="col-md-2">
                                <select name="item_type[]" class="form-select item-type" onchange="toggleOrderRow(this)">
                                    <option value="viand">Viand</option>
                                    <option value="product">Product</option>
                                </select>
                            </div>
                            <div class="col-md-3 viand-col">
                                <select name="viand_id[]" class="form-select">
                                    <option value="">-- Select Viand --</option>
                                    <?php foreach ($viands as $viand): ?>
                                        <option value="<?= (int)$viand['id']; ?>" data-price="<?= htmlspecialchars($viand['selling_price']); ?>">
                                            <?= htmlspecialchars($viand['viand_name']); ?> (₱<?= number_format((float)$viand['selling_price'], 2); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3 product-col d-none">
                                <select name="product_id[]" class="form-select">
                                    <option value="">-- Select Product --</option>
                                    <?php foreach ($products as $product): ?>
                                        <option value="<?= (int)$product['id']; ?>" data-price="<?= htmlspecialchars($product['selling_price']); ?>">
                                            <?= htmlspecialchars($product['product_name']); ?> (₱<?= number_format((float)$product['selling_price'], 2); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-1">
                                <input type="number" step="0.01" min="1" name="quantity[]" class="form-control" value="1" placeholder="Qty">
                            </div>
                            <div class="col-md-2">
                                <input type="number" step="0.01" min="0" name="unit_price[]" class="form-control" placeholder="Unit Price">
                            </div>
                            <div class="col-md-1">
                                <input type="text" name="item_notes[]" class="form-control" placeholder="Note">
                            </div>
                        </div>
                    </div>

                    <div class="d-flex gap-2 mt-3">
                        <button type="button" class="btn btn-outline-secondary" onclick="addOrderRow()">Add Row</button>
                        <button class="btn btn-dark">Save Order</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Order No</th>
                            <th>Type</th>
                            <th>Table / Customer</th>
                            <th>Status</th>
                            <th>Items</th>
                            <th>Total</th>
                            <th>Created</th>
                            <th width="360">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <?php
                                $statusClass = match ($order['status']) {
                                    'pending' => 'secondary',
                                    'preparing' => 'warning',
                                    'ready' => 'success',
                                    'served' => 'info',
                                    'completed' => 'dark',
                                    'cancelled' => 'danger',
                                    default => 'secondary',
                                };
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($order['order_no']); ?></td>
                                <td><?= ucwords(str_replace('_', ' ', htmlspecialchars($order['order_type']))); ?></td>
                                <td>
                                    <?php if (!empty($order['table_name'])): ?>
                                        <div><?= htmlspecialchars($order['table_name']); ?></div>
                                    <?php endif; ?>
                                    <?php if (!empty($order['customer_name'])): ?>
                                        <div class="small text-muted"><?= htmlspecialchars($order['customer_name']); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><span class="badge text-bg-<?= $statusClass; ?>"><?= strtoupper(htmlspecialchars($order['status'])); ?></span></td>
                                <td>
                                    <?php foreach (($order['items'] ?? []) as $item): ?>
                                        <div><?= htmlspecialchars($item['item_name'] ?? '-'); ?> x <?= number_format((float)$item['quantity'], 2); ?></div>
                                    <?php endforeach; ?>
                                </td>
                                <td>₱<?= number_format((float)$order['total_amount'], 2); ?></td>
                                <td><?= htmlspecialchars(date('M d, Y h:i A', strtotime($order['created_at']))); ?></td>
                                <td>
                                    <div class="d-flex flex-wrap gap-2 mb-2">
                                        <a class="btn btn-outline-secondary btn-sm" href="<?= $config['base_url']; ?>/orders/kitchenTicket/<?= (int)$order['id']; ?>" target="_blank">Kitchen Ticket</a>
                                        <?php if (empty($order['sale_id']) && !in_array($order['status'], ['cancelled', 'completed'], true)): ?>
                                            <a class="btn btn-dark btn-sm" href="<?= $config['base_url']; ?>/orders/checkout/<?= (int)$order['id']; ?>" onclick="return confirm('Checkout this order and create receipt?')">Checkout</a>
                                        <?php endif; ?>
                                        <?php if (!empty($order['sale_id'])): ?>
                                            <a class="btn btn-primary btn-sm" href="<?= $config['base_url']; ?>/orders/receipt/<?= (int)$order['id']; ?>" target="_blank">Receipt</a>
                                        <?php endif; ?>
                                    </div>
                                    <form method="POST" action="<?= $config['base_url']; ?>/orders/updateStatus/<?= (int)$order['id']; ?>" class="d-flex gap-2">
                                        <select name="status" class="form-select form-select-sm">
                                            <?php foreach (['pending','preparing','ready','served','completed','cancelled'] as $status): ?>
                                                <option value="<?= $status; ?>" <?= ($order['status'] === $status) ? 'selected' : ''; ?>>
                                                    <?= ucwords(str_replace('_', ' ', $status)); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button class="btn btn-primary btn-sm">Save</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        <?php if (empty($orders)): ?>
                            <tr><td colspan="8" class="text-center text-muted">No orders found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<script>
function toggleOrderFields() {
    const orderType = document.getElementById('orderType').value;
    document.querySelectorAll('.dine-in-field').forEach(el => el.classList.toggle('d-none', orderType !== 'dine_in'));
    document.querySelectorAll('.customer-field').forEach(el => el.classList.toggle('d-none', orderType === 'dine_in'));
}

function toggleOrderRow(selectEl) {
    const row = selectEl.closest('.order-row');
    const viandCol = row.querySelector('.viand-col');
    const productCol = row.querySelector('.product-col');

    if (selectEl.value === 'product') {
        viandCol.classList.add('d-none');
        productCol.classList.remove('d-none');
    } else {
        productCol.classList.add('d-none');
        viandCol.classList.remove('d-none');
    }
}

function addOrderRow() {
    const wrapper = document.getElementById('order-items-wrapper');
    const first = wrapper.querySelector('.order-row');
    const clone = first.cloneNode(true);

    clone.querySelectorAll('input').forEach(el => {
        if (el.name === 'quantity[]') el.value = '1';
        else el.value = '';
    });
    clone.querySelectorAll('select').forEach(el => el.selectedIndex = 0);
    clone.querySelector('.product-col').classList.add('d-none');
    clone.querySelector('.viand-col').classList.remove('d-none');

    wrapper.appendChild(clone);
}

document.addEventListener('change', function(e) {
    const row = e.target.closest('.order-row');
    if (!row) return;

    if (e.target.name === 'viand_id[]') {
        const price = e.target.options[e.target.selectedIndex]?.dataset?.price || '';
        row.querySelector('input[name="unit_price[]"]').value = price;
    }

    if (e.target.name === 'product_id[]') {
        const price = e.target.options[e.target.selectedIndex]?.dataset?.price || '';
        row.querySelector('input[name="unit_price[]"]').value = price;
    }
});

toggleOrderFields();
</script>

<?php require APP_PATH . '/views/layouts/footer.php'; ?>
