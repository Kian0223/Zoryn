ALTER TABLE orders
  ADD COLUMN cancellation_reason VARCHAR(255) DEFAULT NULL AFTER updated_at;

ALTER TABLE sales
  ADD COLUMN sale_status ENUM('completed','voided','refunded') NOT NULL DEFAULT 'completed' AFTER change_amount,
  ADD COLUMN void_reason VARCHAR(255) DEFAULT NULL AFTER sale_status,
  ADD COLUMN refunded_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER void_reason;

CREATE TABLE IF NOT EXISTS reservation_logs (
  id INT(11) NOT NULL AUTO_INCREMENT,
  reservation_id INT(11) NOT NULL,
  action_type ENUM('created','updated','status_changed','deleted') NOT NULL,
  action_note VARCHAR(255) DEFAULT NULL,
  created_by INT(11) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS sale_adjustments (
  id INT(11) NOT NULL AUTO_INCREMENT,
  sale_id INT(11) NOT NULL,
  adjustment_type ENUM('void','refund') NOT NULL,
  reason VARCHAR(255) DEFAULT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_by INT(11) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
