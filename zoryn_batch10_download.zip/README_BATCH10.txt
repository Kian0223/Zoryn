ZORYN BATCH 10 INSTALLATION
===========================

This batch adds:
- AP due dates on grocery purchases
- AP aging buckets
- AP terms/default due days
- Auto-post grocery purchases to expenses when received

INSTALL ORDER
-------------
1. Run: sql/batch10_ap_aging_due_dates.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch10.css if you want the extra styling

ROUTES ADDED / UPDATED
----------------------
/apterms/index
/apterms/store
/grocerypurchases/index
/grocerypurchases/store
/grocerypurchases/receive/{id}

NOTES
-----
- Due date is saved on the purchase and used for AP aging.
- Default AP term auto-fills due date from purchase date.
- Receiving a grocery purchase auto-posts it to Expenses once.
- Expense auto-posting uses category: Supplies.
