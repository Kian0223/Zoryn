ZORYN BATCH 4 INSTALLATION
==========================

This batch adds:
- reservation -> order prefill flow
- order checkout into sales + receipt
- kitchen ticket print view
- receipt print view

INSTALL ORDER
-------------
1. No required SQL change for this batch
2. Copy the PHP files into your project folders
3. Optional: merge public/assets/css/batch4.css into your main style.css

ROUTES ADDED / UPDATED
----------------------
/orders/index?reservation_id={id}
/orders/kitchenTicket/{id}
/orders/checkout/{id}
/orders/receipt/{id}

NOTES
-----
- Checkout deducts stock the same way the POS page does.
- Receipt is created by generating a real sales record from the order.
- Reservations page now includes a Create Order button for confirmed/seated reservations.
- This batch does not prevent double checkout if you manually duplicate the flow outside Orders.
