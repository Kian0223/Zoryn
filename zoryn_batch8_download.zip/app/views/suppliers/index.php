<?php require APP_PATH . '/views/layouts/header.php'; ?>
<div class="d-flex">
<?php require APP_PATH . '/views/layouts/sidebar.php'; ?>
<main class="content-area flex-grow-1 p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">Suppliers</h2>
    </div>

    <?php require APP_PATH . '/views/partials/alerts.php'; ?>

    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <h5 class="mb-3">Add Supplier</h5>
            <form method="POST" action="<?= $config['base_url']; ?>/suppliers/store">
                <div class="row g-3">
                    <div class="col-md-3"><label class="form-label">Supplier Name</label><input type="text" name="supplier_name" class="form-control" required></div>
                    <div class="col-md-2"><label class="form-label">Contact Person</label><input type="text" name="contact_person" class="form-control"></div>
                    <div class="col-md-2"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"></div>
                    <div class="col-md-2"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div>
                    <div class="col-md-3"><label class="form-label">Address</label><input type="text" name="address" class="form-control"></div>
                    <div class="col-md-9"><label class="form-label">Notes</label><input type="text" name="notes" class="form-control"></div>
                    <div class="col-md-3 d-grid"><label class="form-label opacity-0">Save</label><button class="btn btn-dark">Save Supplier</button></div>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Notes</th>
                        <th width="170">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (($suppliers ?? []) as $supplier): ?>
                        <tr>
                            <td><?= htmlspecialchars($supplier['supplier_name']); ?></td>
                            <td><?= htmlspecialchars($supplier['contact_person'] ?? '-'); ?></td>
                            <td><?= htmlspecialchars($supplier['phone'] ?? '-'); ?></td>
                            <td><?= htmlspecialchars($supplier['email'] ?? '-'); ?></td>
                            <td><?= htmlspecialchars($supplier['address'] ?? '-'); ?></td>
                            <td><?= htmlspecialchars($supplier['notes'] ?? '-'); ?></td>
                            <td>
                                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editSupplierModal<?= (int)$supplier['id']; ?>">Edit</button>
                                <a class="btn btn-danger btn-sm" onclick="return confirm('Delete this supplier?')" href="<?= $config['base_url']; ?>/suppliers/delete/<?= (int)$supplier['id']; ?>">Del</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($suppliers)): ?>
                        <tr><td colspan="7" class="text-center text-muted">No suppliers found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
</div>

<?php foreach (($suppliers ?? []) as $supplier): ?>
<div class="modal fade" id="editSupplierModal<?= (int)$supplier['id']; ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0">
            <form method="POST" action="<?= $config['base_url']; ?>/suppliers/update/<?= (int)$supplier['id']; ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Supplier</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-4"><label class="form-label">Supplier Name</label><input type="text" name="supplier_name" class="form-control" value="<?= htmlspecialchars($supplier['supplier_name']); ?>" required></div>
                        <div class="col-md-4"><label class="form-label">Contact Person</label><input type="text" name="contact_person" class="form-control" value="<?= htmlspecialchars($supplier['contact_person'] ?? ''); ?>"></div>
                        <div class="col-md-4"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($supplier['phone'] ?? ''); ?>"></div>
                        <div class="col-md-4"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($supplier['email'] ?? ''); ?>"></div>
                        <div class="col-md-4"><label class="form-label">Address</label><input type="text" name="address" class="form-control" value="<?= htmlspecialchars($supplier['address'] ?? ''); ?>"></div>
                        <div class="col-md-4"><label class="form-label">Notes</label><input type="text" name="notes" class="form-control" value="<?= htmlspecialchars($supplier['notes'] ?? ''); ?>"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-dark">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php require APP_PATH . '/views/layouts/footer.php'; ?>
