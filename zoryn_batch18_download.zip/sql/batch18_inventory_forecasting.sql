CREATE TABLE IF NOT EXISTS supplier_grocery_links (
  id INT(11) NOT NULL AUTO_INCREMENT,
  supplier_id INT(11) NOT NULL,
  grocery_id INT(11) NOT NULL,
  lead_time_days INT(11) NOT NULL DEFAULT 3,
  preferred_flag TINYINT(1) NOT NULL DEFAULT 0,
  last_cost DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  notes VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uq_supplier_grocery (supplier_id, grocery_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE groceries
  ADD COLUMN reorder_point DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER low_stock_threshold,
  ADD COLUMN reorder_quantity DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER reorder_point,
  ADD COLUMN safety_stock DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER reorder_quantity;
