<?php
class GroceryPurchase extends Model
{
    public function getAll(): array
    {
        $this->db->query("
            SELECT gp.*, s.supplier_name, u.full_name
            FROM grocery_purchases gp
            LEFT JOIN suppliers s ON s.id = gp.supplier_id
            LEFT JOIN users u ON u.id = gp.created_by
            ORDER BY gp.id DESC
        ");
        $rows = $this->db->resultSet();

        foreach ($rows as &$row) {
            $row['items'] = $this->getItems((int)$row['id']);
        }
        return $rows;
    }

    public function getItems(int $purchaseId): array
    {
        $this->db->query("
            SELECT gpi.*, g.grocery_name, g.unit
            FROM grocery_purchase_items gpi
            LEFT JOIN groceries g ON g.id = gpi.grocery_id
            WHERE gpi.purchase_id = :purchase_id
            ORDER BY gpi.id ASC
        ");
        $this->db->bind(':purchase_id', $purchaseId);
        return $this->db->resultSet();
    }

    public function findById(int $id): array|false
    {
        $this->db->query("
            SELECT gp.*, s.supplier_name
            FROM grocery_purchases gp
            LEFT JOIN suppliers s ON s.id = gp.supplier_id
            WHERE gp.id = :id
            LIMIT 1
        ");
        $this->db->bind(':id', $id);
        $row = $this->db->single();
        if (!$row) return false;
        $row['items'] = $this->getItems($id);
        return $row;
    }

    public function create(array $header, array $items): int|false
    {
        $purchaseNo = 'GP-' . date('Ymd-His') . '-' . rand(100, 999);
        $totalAmount = 0;
        foreach ($items as $item) {
            $totalAmount += (float)$item['line_total'];
        }

        $this->db->query("
            INSERT INTO grocery_purchases (
                purchase_no, supplier_id, purchase_date, status, total_amount, notes, created_by, created_at
            ) VALUES (
                :purchase_no, :supplier_id, :purchase_date, :status, :total_amount, :notes, :created_by, NOW()
            )
        ");
        $this->db->bind(':purchase_no', $purchaseNo);
        $this->db->bind(':supplier_id', $header['supplier_id'] ?: null);
        $this->db->bind(':purchase_date', $header['purchase_date']);
        $this->db->bind(':status', $header['status'] ?? 'draft');
        $this->db->bind(':total_amount', $totalAmount);
        $this->db->bind(':notes', $header['notes'] ?: null);
        $this->db->bind(':created_by', $header['created_by'] ?? null);

        if (!$this->db->execute()) return false;

        $purchaseId = (int)$this->db->lastInsertId();

        foreach ($items as $item) {
            $this->db->query("
                INSERT INTO grocery_purchase_items (
                    purchase_id, grocery_id, package_count, package_quantity, package_cost, total_quantity, line_total
                ) VALUES (
                    :purchase_id, :grocery_id, :package_count, :package_quantity, :package_cost, :total_quantity, :line_total
                )
            ");
            $this->db->bind(':purchase_id', $purchaseId);
            $this->db->bind(':grocery_id', $item['grocery_id']);
            $this->db->bind(':package_count', $item['package_count']);
            $this->db->bind(':package_quantity', $item['package_quantity']);
            $this->db->bind(':package_cost', $item['package_cost']);
            $this->db->bind(':total_quantity', $item['total_quantity']);
            $this->db->bind(':line_total', $item['line_total']);
            if (!$this->db->execute()) return false;
        }

        return $purchaseId;
    }

    public function markReceived(int $id): bool
    {
        $this->db->query("
            UPDATE grocery_purchases
            SET status = 'received',
                received_at = NOW()
            WHERE id = :id AND status = 'draft'
        ");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function markCancelled(int $id): bool
    {
        $this->db->query("
            UPDATE grocery_purchases
            SET status = 'cancelled'
            WHERE id = :id AND status = 'draft'
        ");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function getSummary(): array
    {
        $this->db->query("
            SELECT
                COUNT(*) AS total_purchases,
                SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) AS draft_purchases,
                SUM(CASE WHEN status = 'received' THEN 1 ELSE 0 END) AS received_purchases,
                COALESCE(SUM(CASE WHEN status = 'received' THEN total_amount ELSE 0 END), 0) AS received_total
            FROM grocery_purchases
        ");
        return $this->db->single() ?: [
            'total_purchases' => 0,
            'draft_purchases' => 0,
            'received_purchases' => 0,
            'received_total' => 0,
        ];
    }
}
