-- Zoryn Restaurant Batch 2
-- Orders + Tables + basic dine-in / takeout / delivery workflow

CREATE TABLE IF NOT EXISTS dining_tables (
  id INT(11) NOT NULL AUTO_INCREMENT,
  table_name VARCHAR(100) NOT NULL,
  capacity INT(11) NOT NULL DEFAULT 4,
  area VARCHAR(100) DEFAULT NULL,
  status ENUM('available','occupied','reserved','maintenance') NOT NULL DEFAULT 'available',
  created_at TIMESTAMP NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS orders (
  id INT(11) NOT NULL AUTO_INCREMENT,
  order_no VARCHAR(50) NOT NULL,
  order_type ENUM('dine_in','takeout','delivery') NOT NULL DEFAULT 'dine_in',
  status ENUM('pending','preparing','ready','served','completed','cancelled') NOT NULL DEFAULT 'pending',
  table_id INT(11) DEFAULT NULL,
  customer_name VARCHAR(150) DEFAULT NULL,
  customer_phone VARCHAR(50) DEFAULT NULL,
  notes TEXT DEFAULT NULL,
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  sale_id INT(11) DEFAULT NULL,
  created_by INT(11) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  updated_at DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_orders_order_no (order_no),
  KEY fk_orders_table (table_id),
  KEY fk_orders_user (created_by),
  KEY fk_orders_sale (sale_id),
  CONSTRAINT fk_orders_table FOREIGN KEY (table_id) REFERENCES dining_tables (id) ON DELETE SET NULL,
  CONSTRAINT fk_orders_user FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL,
  CONSTRAINT fk_orders_sale FOREIGN KEY (sale_id) REFERENCES sales (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS order_items (
  id INT(11) NOT NULL AUTO_INCREMENT,
  order_id INT(11) NOT NULL,
  viand_id INT(11) DEFAULT NULL,
  product_id INT(11) DEFAULT NULL,
  quantity DECIMAL(12,2) NOT NULL DEFAULT 1.00,
  unit_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  line_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  notes VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id),
  KEY fk_order_items_order (order_id),
  KEY fk_order_items_viand (viand_id),
  KEY fk_order_items_product (product_id),
  CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
  CONSTRAINT fk_order_items_viand FOREIGN KEY (viand_id) REFERENCES viands (id) ON DELETE SET NULL,
  CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO dining_tables (table_name, capacity, area, status)
SELECT 'Table 1', 4, 'Main Hall', 'available'
WHERE NOT EXISTS (SELECT 1 FROM dining_tables WHERE table_name = 'Table 1');

INSERT INTO dining_tables (table_name, capacity, area, status)
SELECT 'Table 2', 4, 'Main Hall', 'available'
WHERE NOT EXISTS (SELECT 1 FROM dining_tables WHERE table_name = 'Table 2');

INSERT INTO dining_tables (table_name, capacity, area, status)
SELECT 'Table 3', 6, 'Main Hall', 'available'
WHERE NOT EXISTS (SELECT 1 FROM dining_tables WHERE table_name = 'Table 3');

INSERT INTO dining_tables (table_name, capacity, area, status)
SELECT 'Table 4', 2, 'Window Side', 'available'
WHERE NOT EXISTS (SELECT 1 FROM dining_tables WHERE table_name = 'Table 4');
