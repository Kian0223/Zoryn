ZORYN BATCH 5 INSTALLATION
==========================

This batch adds:
- Kitchen Display page
- Payment method tracking at checkout
- Bill preview page
- Improved receipt with payment details

INSTALL ORDER
-------------
1. Run: sql/batch5_payments_kds.sql
2. Copy the PHP files into your project folders
3. Optional: merge public/assets/css/batch5.css into your main style.css

ROUTES ADDED / UPDATED
----------------------
/kitchen/index
/orders/bill/{id}
/orders/checkout/{id}    (now POST with payment fields)
/orders/receipt/{id}

NOTES
-----
- Checkout now happens from the Orders page modal.
- Kitchen Display shows pending, preparing, and ready orders.
- Bill is a printable pre-checkout summary.
- Receipt now shows payment method, reference, paid amount, and change.
