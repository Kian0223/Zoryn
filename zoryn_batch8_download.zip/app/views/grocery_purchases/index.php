<?php require APP_PATH . '/views/layouts/header.php'; ?>
<div class="d-flex">
<?php require APP_PATH . '/views/layouts/sidebar.php'; ?>
<main class="content-area flex-grow-1 p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">Grocery Receiving</h2>
    </div>

    <?php require APP_PATH . '/views/partials/alerts.php'; ?>

    <div class="row g-4 mb-4">
        <div class="col-md-3"><div class="card shadow-sm border-0 h-100"><div class="card-body"><div class="text-muted small">Total Purchases</div><h3 class="mb-0"><?= (int)($summary['total_purchases'] ?? 0); ?></h3></div></div></div>
        <div class="col-md-3"><div class="card shadow-sm border-0 h-100"><div class="card-body"><div class="text-muted small">Draft</div><h3 class="mb-0 text-warning"><?= (int)($summary['draft_purchases'] ?? 0); ?></h3></div></div></div>
        <div class="col-md-3"><div class="card shadow-sm border-0 h-100"><div class="card-body"><div class="text-muted small">Received</div><h3 class="mb-0 text-success"><?= (int)($summary['received_purchases'] ?? 0); ?></h3></div></div></div>
        <div class="col-md-3"><div class="card shadow-sm border-0 h-100"><div class="card-body"><div class="text-muted small">Received Total</div><h3 class="mb-0">₱<?= number_format((float)($summary['received_total'] ?? 0), 2); ?></h3></div></div></div>
    </div>

    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <h5 class="mb-3">Create Grocery Purchase</h5>
            <form method="POST" action="<?= $config['base_url']; ?>/grocerypurchases/store">
                <div class="row g-3 mb-3">
                    <div class="col-md-3">
                        <label class="form-label">Supplier</label>
                        <select name="supplier_id" class="form-select">
                            <option value="">-- Optional Supplier --</option>
                            <?php foreach (($suppliers ?? []) as $supplier): ?>
                                <option value="<?= (int)$supplier['id']; ?>"><?= htmlspecialchars($supplier['supplier_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Purchase Date</label>
                        <input type="date" name="purchase_date" class="form-control" value="<?= date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Notes</label>
                        <input type="text" name="notes" class="form-control" placeholder="Optional note">
                    </div>
                </div>

                <div id="purchase-items-wrapper">
                    <div class="row g-2 purchase-row mb-2">
                        <div class="col-md-4">
                            <select name="grocery_id[]" class="form-select">
                                <option value="">-- Select Grocery --</option>
                                <?php foreach (($groceries ?? []) as $grocery): ?>
                                    <option value="<?= (int)$grocery['id']; ?>" data-package-quantity="<?= htmlspecialchars($grocery['package_quantity'] ?? 0); ?>" data-package-cost="<?= htmlspecialchars($grocery['package_cost'] ?? 0); ?>">
                                        <?= htmlspecialchars($grocery['grocery_name']); ?> (<?= htmlspecialchars($grocery['unit'] ?? ''); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2"><input type="number" step="0.01" min="0.01" name="package_count[]" class="form-control purchase-package-count" value="1" placeholder="Pack Count"></div>
                        <div class="col-md-2"><input type="number" step="0.01" min="0.01" name="package_quantity[]" class="form-control purchase-package-quantity" placeholder="Pack Qty"></div>
                        <div class="col-md-2"><input type="number" step="0.01" min="0" name="package_cost[]" class="form-control purchase-package-cost" placeholder="Pack Cost"></div>
                        <div class="col-md-2"><input type="text" class="form-control purchase-line-total" placeholder="Line Total" readonly></div>
                    </div>
                </div>

                <div class="d-flex gap-2 mt-3">
                    <button type="button" class="btn btn-outline-secondary" onclick="addPurchaseRow()">Add Row</button>
                    <button class="btn btn-dark">Save Draft Purchase</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Purchase No</th>
                        <th>Supplier</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Items</th>
                        <th>Total</th>
                        <th width="220">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (($purchases ?? []) as $purchase): ?>
                        <tr>
                            <td><?= htmlspecialchars($purchase['purchase_no']); ?></td>
                            <td><?= htmlspecialchars($purchase['supplier_name'] ?? '-'); ?></td>
                            <td><?= htmlspecialchars($purchase['purchase_date']); ?></td>
                            <td><span class="badge text-bg-<?= ($purchase['status'] === 'received') ? 'success' : (($purchase['status'] === 'cancelled') ? 'danger' : 'warning'); ?>"><?= strtoupper(htmlspecialchars($purchase['status'])); ?></span></td>
                            <td>
                                <?php foreach (($purchase['items'] ?? []) as $item): ?>
                                    <div><?= htmlspecialchars($item['grocery_name'] ?? '-'); ?> · <?= number_format((float)$item['package_count'], 2); ?> × <?= number_format((float)$item['package_quantity'], 2); ?></div>
                                <?php endforeach; ?>
                            </td>
                            <td>₱<?= number_format((float)$purchase['total_amount'], 2); ?></td>
                            <td>
                                <?php if (($purchase['status'] ?? '') === 'draft'): ?>
                                    <a class="btn btn-success btn-sm" onclick="return confirm('Receive this purchase and add stock?')" href="<?= $config['base_url']; ?>/grocerypurchases/receive/<?= (int)$purchase['id']; ?>">Receive</a>
                                    <a class="btn btn-danger btn-sm" onclick="return confirm('Cancel this draft purchase?')" href="<?= $config['base_url']; ?>/grocerypurchases/cancel/<?= (int)$purchase['id']; ?>">Cancel</a>
                                <?php else: ?>
                                    <span class="text-muted small">No actions</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($purchases)): ?>
                        <tr><td colspan="7" class="text-center text-muted">No grocery purchases found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
</div>

<script>
function computePurchaseRow(row) {
    const count = parseFloat(row.querySelector('.purchase-package-count').value) || 0;
    const cost = parseFloat(row.querySelector('.purchase-package-cost').value) || 0;
    row.querySelector('.purchase-line-total').value = (count * cost).toFixed(2);
}

function addPurchaseRow() {
    const wrapper = document.getElementById('purchase-items-wrapper');
    const first = wrapper.querySelector('.purchase-row');
    const clone = first.cloneNode(true);

    clone.querySelectorAll('input').forEach(el => {
        if (el.classList.contains('purchase-package-count')) el.value = '1';
        else el.value = '';
    });
    clone.querySelectorAll('select').forEach(el => el.selectedIndex = 0);
    wrapper.appendChild(clone);
}

document.addEventListener('change', function(e) {
    const row = e.target.closest('.purchase-row');
    if (!row) return;

    if (e.target.name === 'grocery_id[]') {
        const opt = e.target.options[e.target.selectedIndex];
        if (opt) {
            row.querySelector('.purchase-package-quantity').value = opt.dataset.packageQuantity || '';
            row.querySelector('.purchase-package-cost').value = opt.dataset.packageCost || '';
            computePurchaseRow(row);
        }
    }
});

document.addEventListener('input', function(e) {
    const row = e.target.closest('.purchase-row');
    if (!row) return;
    if (e.target.classList.contains('purchase-package-count') || e.target.classList.contains('purchase-package-cost')) {
        computePurchaseRow(row);
    }
});
</script>

<?php require APP_PATH . '/views/layouts/footer.php'; ?>
