ZORYN BATCH 13 INSTALLATION
===========================

This batch adds:
- Customer database
- Loyalty points ledger
- Loyalty analytics
- Checkout customer tagging and points earning/redeeming

INSTALL ORDER
-------------
1. Run: sql/batch13_customers_loyalty.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch13.css if you want the extra styling

ROUTES ADDED
------------
/customers/index
/customers/store
/customers/update/{id}
/customers/delete/{id}
/loyalty/index
/loyalty/adjust/{customerId}

NOTES
-----
- Checkout now supports optional customer selection.
- Default loyalty rule in this batch: 1 point per ₱100 net sale.
- Redeemed points are treated as ₱1 discount per point.
- Loyalty adjustments can be added manually from Loyalty Analytics.
