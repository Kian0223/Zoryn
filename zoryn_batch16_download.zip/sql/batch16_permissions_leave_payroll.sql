CREATE TABLE IF NOT EXISTS leave_requests (
  id INT(11) NOT NULL AUTO_INCREMENT,
  employee_id INT(11) NOT NULL,
  leave_type ENUM('sick','vacation','emergency','unpaid','other') NOT NULL DEFAULT 'vacation',
  date_from DATE NOT NULL,
  date_to DATE NOT NULL,
  days_count DECIMAL(10,2) NOT NULL DEFAULT 1.00,
  reason VARCHAR(255) DEFAULT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  approved_by INT(11) DEFAULT NULL,
  approved_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS payroll_adjustments (
  id INT(11) NOT NULL AUTO_INCREMENT,
  employee_id INT(11) NOT NULL,
  adjustment_date DATE NOT NULL,
  adjustment_type ENUM('allowance','deduction') NOT NULL DEFAULT 'allowance',
  adjustment_name VARCHAR(150) NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  notes VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
