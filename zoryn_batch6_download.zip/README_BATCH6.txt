ZORYN BATCH 6 INSTALLATION
==========================

This batch adds:
- Reservation calendar view
- Reservation action logs
- Order cancellation reason field
- Sale void / refund logging workflow

INSTALL ORDER
-------------
1. Run: sql/batch6_ops_control.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch6.css if you want the extra styling

ROUTES ADDED / UPDATED
----------------------
/reservations/index?month=YYYY-MM
/salesadjustments/store/{saleId}

NOTES
-----
- Reports page now lets you void or refund completed sales.
- Reservations page now includes a monthly grouped calendar view.
- Reservation actions are logged in reservation_logs.
- This batch records operational controls but does not yet restock inventory on void/refund.
