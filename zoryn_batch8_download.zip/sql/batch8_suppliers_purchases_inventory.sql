CREATE TABLE IF NOT EXISTS suppliers (
  id INT(11) NOT NULL AUTO_INCREMENT,
  supplier_name VARCHAR(150) NOT NULL,
  contact_person VARCHAR(150) DEFAULT NULL,
  phone VARCHAR(50) DEFAULT NULL,
  email VARCHAR(150) DEFAULT NULL,
  address VARCHAR(255) DEFAULT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS grocery_purchases (
  id INT(11) NOT NULL AUTO_INCREMENT,
  purchase_no VARCHAR(50) NOT NULL,
  supplier_id INT(11) DEFAULT NULL,
  purchase_date DATE NOT NULL,
  status ENUM('draft','received','cancelled') NOT NULL DEFAULT 'draft',
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  notes VARCHAR(255) DEFAULT NULL,
  created_by INT(11) DEFAULT NULL,
  received_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uq_purchase_no (purchase_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS grocery_purchase_items (
  id INT(11) NOT NULL AUTO_INCREMENT,
  purchase_id INT(11) NOT NULL,
  grocery_id INT(11) NOT NULL,
  package_count DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  package_quantity DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  package_cost DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total_quantity DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  line_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
