ZORYN BATCH 9 INSTALLATION
==========================

This batch adds:
- Supplier payments
- Purchase balances / payables
- Expense supplier tagging

INSTALL ORDER
-------------
1. Run: sql/batch9_supplier_payables.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch9.css if you want the extra styling

ROUTES ADDED / UPDATED
----------------------
/supplierpayments/index
/supplierpayments/store
/expenses/index
/expenses/store

NOTES
-----
- Purchase balances update when a supplier payment is linked to a purchase.
- Supplier list now shows total balance due from received purchases.
- Expense form now supports optional supplier tagging in notes.
