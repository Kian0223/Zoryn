<?php require APP_PATH . '/views/layouts/header.php'; ?>
<div class="d-flex">
    <?php require APP_PATH . '/views/layouts/sidebar.php'; ?>
    <main class="content-area flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Reservations</h2>
        </div>

        <?php require APP_PATH . '/views/partials/alerts.php'; ?>

        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body">
                        <div class="text-muted small">Today Reservations</div>
                        <h3 class="mb-0"><?= (int)($summary['total_today'] ?? 0); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body">
                        <div class="text-muted small">Pending</div>
                        <h3 class="mb-0 text-warning"><?= (int)($summary['pending_today'] ?? 0); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body">
                        <div class="text-muted small">Confirmed</div>
                        <h3 class="mb-0 text-info"><?= (int)($summary['confirmed_today'] ?? 0); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body">
                        <div class="text-muted small">Seated</div>
                        <h3 class="mb-0 text-success"><?= (int)($summary['seated_today'] ?? 0); ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <h5 class="mb-3">Add Reservation</h5>
                <form method="POST" action="<?= $config['base_url']; ?>/reservations/store">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Customer Name</label>
                            <input type="text" name="customer_name" class="form-control" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Phone</label>
                            <input type="text" name="customer_phone" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Email</label>
                            <input type="email" name="customer_email" class="form-control">
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Pax</label>
                            <input type="number" name="pax_count" min="1" class="form-control" value="2" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Date</label>
                            <input type="date" name="reservation_date" class="form-control" value="<?= date('Y-m-d'); ?>" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Time</label>
                            <input type="time" name="reservation_time" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Assign Table</label>
                            <select name="table_id" class="form-select">
                                <option value="">-- Optional Table --</option>
                                <?php foreach ($tables as $table): ?>
                                    <option value="<?= (int)$table['id']; ?>" <?= in_array($table['status'], ['available', 'reserved'], true) ? '' : 'disabled'; ?>>
                                        <?= htmlspecialchars($table['table_name']); ?> (<?= (int)$table['capacity']; ?> pax)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="seated">Seated</option>
                            </select>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label">Notes</label>
                            <input type="text" name="notes" class="form-control" placeholder="Optional note">
                        </div>
                        <div class="col-md-2 d-grid">
                            <label class="form-label opacity-0">Save</label>
                            <button class="btn btn-dark">Save Reservation</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Reservation No</th>
                            <th>Guest</th>
                            <th>Date & Time</th>
                            <th>Pax</th>
                            <th>Table</th>
                            <th>Status</th>
                            <th>Notes</th>
                            <th width="360">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reservations as $reservation): ?>
                            <?php
                                $statusClass = match ($reservation['status']) {
                                    'pending' => 'secondary',
                                    'confirmed' => 'info',
                                    'seated' => 'success',
                                    'completed' => 'dark',
                                    'cancelled' => 'danger',
                                    'no_show' => 'warning',
                                    default => 'secondary',
                                };
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($reservation['reservation_no']); ?></td>
                                <td>
                                    <div><?= htmlspecialchars($reservation['customer_name']); ?></div>
                                    <?php if (!empty($reservation['customer_phone'])): ?>
                                        <div class="small text-muted"><?= htmlspecialchars($reservation['customer_phone']); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= htmlspecialchars(date('M d, Y', strtotime($reservation['reservation_date']))); ?><br>
                                    <span class="small text-muted"><?= htmlspecialchars(date('h:i A', strtotime($reservation['reservation_time']))); ?></span>
                                </td>
                                <td><?= (int)$reservation['pax_count']; ?></td>
                                <td><?= htmlspecialchars($reservation['table_name'] ?? '-'); ?></td>
                                <td><span class="badge text-bg-<?= $statusClass; ?>"><?= strtoupper(str_replace('_', ' ', htmlspecialchars($reservation['status']))); ?></span></td>
                                <td><?= htmlspecialchars($reservation['notes'] ?? '-'); ?></td>
                                <td>
                                    <div class="d-flex flex-wrap gap-2 mb-2">
                                        <?php if (in_array($reservation['status'], ['confirmed','seated'], true)): ?>
                                            <a class="btn btn-dark btn-sm" href="<?= $config['base_url']; ?>/orders/index?reservation_id=<?= (int)$reservation['id']; ?>">Create Order</a>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editReservationModal<?= (int)$reservation['id']; ?>">Edit</button>
                                        <a class="btn btn-danger btn-sm" onclick="return confirm('Delete this reservation?')" href="<?= $config['base_url']; ?>/reservations/delete/<?= (int)$reservation['id']; ?>">Del</a>
                                    </div>
                                    <form method="POST" action="<?= $config['base_url']; ?>/reservations/updateStatus/<?= (int)$reservation['id']; ?>" class="d-flex gap-2">
                                        <select name="status" class="form-select form-select-sm">
                                            <?php foreach (['pending','confirmed','seated','completed','cancelled','no_show'] as $status): ?>
                                                <option value="<?= $status; ?>" <?= ($reservation['status'] === $status) ? 'selected' : ''; ?>>
                                                    <?= ucwords(str_replace('_', ' ', $status)); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button class="btn btn-outline-secondary btn-sm">Save</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        <?php if (empty($reservations)): ?>
                            <tr><td colspan="8" class="text-center text-muted">No reservations found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<?php foreach ($reservations as $reservation): ?>
    <div class="modal fade" id="editReservationModal<?= (int)$reservation['id']; ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0">
                <form method="POST" action="<?= $config['base_url']; ?>/reservations/update/<?= (int)$reservation['id']; ?>">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Reservation</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Customer Name</label>
                                <input type="text" name="customer_name" class="form-control" value="<?= htmlspecialchars($reservation['customer_name']); ?>" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Phone</label>
                                <input type="text" name="customer_phone" class="form-control" value="<?= htmlspecialchars($reservation['customer_phone'] ?? ''); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="customer_email" class="form-control" value="<?= htmlspecialchars($reservation['customer_email'] ?? ''); ?>">
                            </div>
                            <div class="col-md-1">
                                <label class="form-label">Pax</label>
                                <input type="number" name="pax_count" min="1" class="form-control" value="<?= (int)$reservation['pax_count']; ?>" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-select">
                                    <?php foreach (['pending','confirmed','seated','completed','cancelled','no_show'] as $status): ?>
                                        <option value="<?= $status; ?>" <?= ($reservation['status'] === $status) ? 'selected' : ''; ?>>
                                            <?= ucwords(str_replace('_', ' ', $status)); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Date</label>
                                <input type="date" name="reservation_date" class="form-control" value="<?= htmlspecialchars($reservation['reservation_date']); ?>" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Time</label>
                                <input type="time" name="reservation_time" class="form-control" value="<?= htmlspecialchars(substr($reservation['reservation_time'], 0, 5)); ?>" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Assign Table</label>
                                <select name="table_id" class="form-select">
                                    <option value="">-- Optional Table --</option>
                                    <?php foreach ($tables as $table): ?>
                                        <option value="<?= (int)$table['id']; ?>" <?= ((int)($reservation['table_id'] ?? 0) === (int)$table['id']) ? 'selected' : ''; ?>>
                                            <?= htmlspecialchars($table['table_name']); ?> (<?= (int)$table['capacity']; ?> pax)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Notes</label>
                                <input type="text" name="notes" class="form-control" value="<?= htmlspecialchars($reservation['notes'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-dark">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<?php require APP_PATH . '/views/layouts/footer.php'; ?>
