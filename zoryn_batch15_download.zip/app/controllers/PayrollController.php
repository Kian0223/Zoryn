<?php
class PayrollController extends Controller
{
    public function index(): void
    {
        $this->requireLogin();
        $employeeModel = $this->model('Employee');

        $dateFrom = trim($_GET['date_from'] ?? date('Y-m-01'));
        $dateTo = trim($_GET['date_to'] ?? date('Y-m-d'));

        $this->view('payroll/index', [
            'title' => 'Payroll Summary',
            'rows' => $employeeModel->getPayrollSummary($dateFrom, $dateTo),
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
        ]);
    }
}
