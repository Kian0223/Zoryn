<?php
class PurchasePlan extends Model
{
    public function getAll(): array
    {
        $this->db->query("
            SELECT pp.*, u.full_name AS creator_name
            FROM purchase_plans pp
            LEFT JOIN users u ON u.id = pp.created_by
            ORDER BY pp.id DESC
        ");
        $rows = $this->db->resultSet();
        foreach ($rows as &$row) {
            $row['items'] = $this->getItems((int)$row['id']);
        }
        return $rows;
    }

    public function getItems(int $planId): array
    {
        $this->db->query("
            SELECT ppi.*, g.grocery_name, g.unit, s.supplier_name
            FROM purchase_plan_items ppi
            INNER JOIN groceries g ON g.id = ppi.grocery_id
            LEFT JOIN suppliers s ON s.id = ppi.supplier_id
            WHERE ppi.plan_id = :plan_id
            ORDER BY g.grocery_name ASC
        ");
        $this->db->bind(':plan_id', $planId);
        return $this->db->resultSet();
    }

    public function findById(int $id): array|false
    {
        $this->db->query("SELECT * FROM purchase_plans WHERE id = :id LIMIT 1");
        $this->db->bind(':id', $id);
        $row = $this->db->single();
        if (!$row) return false;
        $row['items'] = $this->getItems($id);
        return $row;
    }

    public function createFromSuggestions(array $items, ?int $createdBy, ?string $notes = null): int|false
    {
        $planNo = 'PLAN-' . date('Ymd-His') . '-' . rand(100,999);

        $this->db->query("
            INSERT INTO purchase_plans (plan_no, plan_date, status, notes, created_by, created_at)
            VALUES (:plan_no, CURDATE(), 'draft', :notes, :created_by, NOW())
        ");
        $this->db->bind(':plan_no', $planNo);
        $this->db->bind(':notes', $notes ?: null);
        $this->db->bind(':created_by', $createdBy);
        if (!$this->db->execute()) return false;

        $planId = (int)$this->db->lastInsertId();

        foreach ($items as $item) {
            $suggestedQty = (float)($item['suggested_order_qty'] ?? 0);
            if ($suggestedQty <= 0) continue;

            $this->db->query("
                INSERT INTO purchase_plan_items (
                    plan_id, grocery_id, suggested_qty, approved_qty, unit_cost, estimated_total, supplier_id
                ) VALUES (
                    :plan_id, :grocery_id, :suggested_qty, :approved_qty, :unit_cost, :estimated_total, :supplier_id
                )
            ");
            $this->db->bind(':plan_id', $planId);
            $this->db->bind(':grocery_id', (int)$item['id']);
            $this->db->bind(':suggested_qty', $suggestedQty);
            $this->db->bind(':approved_qty', $suggestedQty);
            $this->db->bind(':unit_cost', (float)($item['latest_cost'] ?? 0));
            $this->db->bind(':estimated_total', (float)($item['estimated_order_cost'] ?? 0));
            $this->db->bind(':supplier_id', $item['preferred_supplier_id'] ?? null);
            if (!$this->db->execute()) return false;
        }

        return $planId;
    }

    public function updateItem(int $itemId, array $data): bool
    {
        $this->db->query("
            UPDATE purchase_plan_items
            SET approved_qty = :approved_qty,
                unit_cost = :unit_cost,
                estimated_total = :estimated_total,
                supplier_id = :supplier_id
            WHERE id = :id
        ");
        $this->db->bind(':approved_qty', $data['approved_qty']);
        $this->db->bind(':unit_cost', $data['unit_cost']);
        $this->db->bind(':estimated_total', $data['estimated_total']);
        $this->db->bind(':supplier_id', $data['supplier_id'] ?: null);
        $this->db->bind(':id', $itemId);
        return $this->db->execute();
    }

    public function updateStatus(int $planId, string $status, ?int $approvedBy = null): bool
    {
        $this->db->query("
            UPDATE purchase_plans
            SET status = :status,
                approved_by = :approved_by,
                approved_at = CASE WHEN :approved_by IS NULL THEN approved_at ELSE NOW() END
            WHERE id = :id
        ");
        $this->db->bind(':status', $status);
        $this->db->bind(':approved_by', $approvedBy);
        $this->db->bind(':id', $planId);
        return $this->db->execute();
    }

    public function getSummary(): array
    {
        $this->db->query("
            SELECT
                COUNT(*) AS total_plans,
                SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) AS draft_plans,
                SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END) AS submitted_plans,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_plans,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_plans
            FROM purchase_plans
        ");
        return $this->db->single() ?: [
            'total_plans'=>0,'draft_plans'=>0,'submitted_plans'=>0,'approved_plans'=>0,'rejected_plans'=>0
        ];
    }
}
