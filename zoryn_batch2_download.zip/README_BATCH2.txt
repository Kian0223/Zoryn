ZORYN BATCH 2 INSTALLATION
==========================

This batch adds:
- Orders page
- Tables page
- Basic dine-in / takeout / delivery workflow
- Sidebar links for Orders and Tables

INSTALL ORDER
-------------
1. Run: sql/batch2_orders_tables.sql
2. Copy the PHP files into your project folders
3. Optional: merge public/assets/css/batch2.css into your main style.css

ROUTES ADDED
------------
/orders/index
/orders/store
/orders/updateStatus/{id}
/tables/index
/tables/store
/tables/update/{id}
/tables/delete/{id}

NOTES
-----
- Dine-in orders require a table.
- Takeout and delivery can use customer name / phone.
- Changing order status to completed or cancelled frees the table.
- This batch does not replace your Sales / POS page; it adds a separate workflow layer.
