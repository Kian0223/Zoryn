<?php
class Employee extends Model
{
    public function getAll(): array
    {
        $this->db->query("
            SELECT e.*, r.role_name, u.username
            FROM employees e
            LEFT JOIN roles r ON r.id = e.role_id
            LEFT JOIN users u ON u.id = e.user_id
            ORDER BY e.full_name ASC
        ");
        return $this->db->resultSet();
    }

    public function create(array $data): bool
    {
        $employeeCode = 'EMP-' . date('Ymd-His') . '-' . rand(100, 999);
        $this->db->query("
            INSERT INTO employees (
                user_id, employee_code, full_name, role_id, job_title,
                daily_rate, hourly_rate, phone, address, hire_date, status, created_at
            ) VALUES (
                :user_id, :employee_code, :full_name, :role_id, :job_title,
                :daily_rate, :hourly_rate, :phone, :address, :hire_date, :status, NOW()
            )
        ");
        $this->db->bind(':user_id', $data['user_id'] ?: null);
        $this->db->bind(':employee_code', $employeeCode);
        $this->db->bind(':full_name', $data['full_name']);
        $this->db->bind(':role_id', $data['role_id'] ?: null);
        $this->db->bind(':job_title', $data['job_title'] ?: null);
        $this->db->bind(':daily_rate', $data['daily_rate']);
        $this->db->bind(':hourly_rate', $data['hourly_rate']);
        $this->db->bind(':phone', $data['phone'] ?: null);
        $this->db->bind(':address', $data['address'] ?: null);
        $this->db->bind(':hire_date', $data['hire_date'] ?: null);
        $this->db->bind(':status', $data['status'] ?? 'active');
        return $this->db->execute();
    }

    public function update(int $id, array $data): bool
    {
        $this->db->query("
            UPDATE employees
            SET user_id = :user_id,
                full_name = :full_name,
                role_id = :role_id,
                job_title = :job_title,
                daily_rate = :daily_rate,
                hourly_rate = :hourly_rate,
                phone = :phone,
                address = :address,
                hire_date = :hire_date,
                status = :status
            WHERE id = :id
        ");
        $this->db->bind(':user_id', $data['user_id'] ?: null);
        $this->db->bind(':full_name', $data['full_name']);
        $this->db->bind(':role_id', $data['role_id'] ?: null);
        $this->db->bind(':job_title', $data['job_title'] ?: null);
        $this->db->bind(':daily_rate', $data['daily_rate']);
        $this->db->bind(':hourly_rate', $data['hourly_rate']);
        $this->db->bind(':phone', $data['phone'] ?: null);
        $this->db->bind(':address', $data['address'] ?: null);
        $this->db->bind(':hire_date', $data['hire_date'] ?: null);
        $this->db->bind(':status', $data['status'] ?? 'active');
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function getPayrollSummary(string $dateFrom, string $dateTo): array
    {
        $this->db->query("
            SELECT
                e.id, e.employee_code, e.full_name, e.job_title, e.daily_rate, e.hourly_rate,
                COALESCE(COUNT(a.id), 0) AS attendance_days,
                COALESCE(SUM(a.hours_worked), 0) AS total_hours,
                COALESCE(SUM(a.overtime_hours), 0) AS overtime_hours,
                COALESCE(SUM(a.hours_worked * e.hourly_rate), 0) AS regular_pay,
                COALESCE(SUM(a.overtime_hours * e.hourly_rate * 1.25), 0) AS overtime_pay,
                COALESCE(SUM(a.hours_worked * e.hourly_rate), 0) + COALESCE(SUM(a.overtime_hours * e.hourly_rate * 1.25), 0) AS gross_pay
            FROM employees e
            LEFT JOIN attendance_logs a
              ON a.employee_id = e.id
             AND a.attendance_date BETWEEN :date_from AND :date_to
             AND a.status IN ('present','late','half_day')
            GROUP BY e.id, e.employee_code, e.full_name, e.job_title, e.daily_rate, e.hourly_rate
            ORDER BY e.full_name ASC
        ");
        $this->db->bind(':date_from', $dateFrom);
        $this->db->bind(':date_to', $dateTo);
        return $this->db->resultSet();
    }
}
