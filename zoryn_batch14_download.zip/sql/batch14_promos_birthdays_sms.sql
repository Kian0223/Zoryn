CREATE TABLE IF NOT EXISTS promo_codes (
  id INT(11) NOT NULL AUTO_INCREMENT,
  code VARCHAR(50) NOT NULL,
  promo_name VARCHAR(150) NOT NULL,
  discount_type ENUM('fixed','percent') NOT NULL DEFAULT 'fixed',
  discount_value DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  min_spend DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  start_date DATE DEFAULT NULL,
  end_date DATE DEFAULT NULL,
  usage_limit INT(11) DEFAULT NULL,
  times_used INT(11) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  notes VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uq_promo_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS promo_redemptions (
  id INT(11) NOT NULL AUTO_INCREMENT,
  promo_id INT(11) NOT NULL,
  sale_id INT(11) DEFAULT NULL,
  customer_id INT(11) DEFAULT NULL,
  discount_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE sales
  ADD COLUMN promo_id INT(11) DEFAULT NULL AFTER loyalty_points_redeemed,
  ADD COLUMN promo_discount_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER promo_id;
