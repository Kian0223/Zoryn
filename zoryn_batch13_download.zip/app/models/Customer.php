<?php
class Customer extends Model
{
    public function getAll(): array
    {
        $this->db->query("
            SELECT *
            FROM customers
            ORDER BY full_name ASC
        ");
        return $this->db->resultSet();
    }

    public function findById(int $id): array|false
    {
        $this->db->query("SELECT * FROM customers WHERE id = :id LIMIT 1");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    public function create(array $data): bool
    {
        $customerCode = 'CUS-' . date('Ymd-His') . '-' . rand(100, 999);

        $this->db->query("
            INSERT INTO customers (
                customer_code, full_name, phone, email, address, birthdate,
                total_points, total_spent, visit_count, created_at
            ) VALUES (
                :customer_code, :full_name, :phone, :email, :address, :birthdate,
                0, 0, 0, NOW()
            )
        ");
        $this->db->bind(':customer_code', $customerCode);
        $this->db->bind(':full_name', $data['full_name']);
        $this->db->bind(':phone', $data['phone'] ?: null);
        $this->db->bind(':email', $data['email'] ?: null);
        $this->db->bind(':address', $data['address'] ?: null);
        $this->db->bind(':birthdate', $data['birthdate'] ?: null);
        return $this->db->execute();
    }

    public function update(int $id, array $data): bool
    {
        $this->db->query("
            UPDATE customers
            SET full_name = :full_name,
                phone = :phone,
                email = :email,
                address = :address,
                birthdate = :birthdate
            WHERE id = :id
        ");
        $this->db->bind(':full_name', $data['full_name']);
        $this->db->bind(':phone', $data['phone'] ?: null);
        $this->db->bind(':email', $data['email'] ?: null);
        $this->db->bind(':address', $data['address'] ?: null);
        $this->db->bind(':birthdate', $data['birthdate'] ?: null);
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function delete(int $id): bool
    {
        $this->db->query("DELETE FROM customers WHERE id = :id");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function applySale(int $customerId, float $spent, float $pointsEarned): bool
    {
        $this->db->query("
            UPDATE customers
            SET total_spent = total_spent + :spent,
                total_points = total_points + :points_earned,
                visit_count = visit_count + 1
            WHERE id = :id
        ");
        $this->db->bind(':spent', $spent);
        $this->db->bind(':points_earned', $pointsEarned);
        $this->db->bind(':id', $customerId);
        return $this->db->execute();
    }

    public function redeemPoints(int $customerId, float $points): bool
    {
        $this->db->query("
            UPDATE customers
            SET total_points = GREATEST(total_points - :points, 0)
            WHERE id = :id
        ");
        $this->db->bind(':points', $points);
        $this->db->bind(':id', $customerId);
        return $this->db->execute();
    }

    public function getTopRepeatCustomers(int $limit = 15): array
    {
        $this->db->query("
            SELECT full_name, phone, email, total_spent, total_points, visit_count
            FROM customers
            ORDER BY visit_count DESC, total_spent DESC
            LIMIT :limit
        ");
        $this->db->bind(':limit', $limit);
        return $this->db->resultSet();
    }

    public function getSummary(): array
    {
        $this->db->query("
            SELECT
                COUNT(*) AS total_customers,
                COALESCE(SUM(total_spent),0) AS total_customer_sales,
                COALESCE(SUM(total_points),0) AS total_points_outstanding,
                COALESCE(AVG(visit_count),0) AS avg_visits
            FROM customers
        ");
        return $this->db->single() ?: [
            'total_customers' => 0,
            'total_customer_sales' => 0,
            'total_points_outstanding' => 0,
            'avg_visits' => 0,
        ];
    }
}
