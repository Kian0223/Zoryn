<?php
class ExpensesController extends Controller
{
    public function index(): void
    {
        $this->requireLogin();

        $dateFrom = trim($_GET['date_from'] ?? date('Y-m-01'));
        $dateTo = trim($_GET['date_to'] ?? date('Y-m-d'));

        $expenseModel = $this->model('Expense');

        $this->view('expenses/index', [
            'title' => 'Expenses',
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'expenses' => $expenseModel->getAll($dateFrom, $dateTo),
            'month_total' => $expenseModel->getCurrentMonthTotal(),
            'range_total' => $expenseModel->getRangeTotal($dateFrom, $dateTo),
            'category_breakdown' => $expenseModel->getCategoryBreakdown($dateFrom, $dateTo),
        ]);
    }

    public function store(): void
    {
        $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('expenses/index');
            return;
        }

        $expenseDate = trim($_POST['expense_date'] ?? date('Y-m-d'));
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? 'Other');
        $amount = (float)($_POST['amount'] ?? 0);
        $paymentMethod = trim($_POST['payment_method'] ?? '');
        $notes = trim($_POST['notes'] ?? '');

        if ($description === '' || $amount <= 0) {
            $_SESSION['error'] = 'Please enter a valid expense description and amount.';
            $this->redirect('expenses/index');
            return;
        }

        $expenseModel = $this->model('Expense');
        $ok = $expenseModel->create([
            'expense_date' => $expenseDate,
            'description' => $description,
            'category' => $category,
            'amount' => $amount,
            'payment_method' => $paymentMethod,
            'notes' => $notes,
            'created_by' => $_SESSION['user']['id'] ?? null,
        ]);

        $_SESSION[$ok ? 'success' : 'error'] = $ok
            ? 'Expense added successfully.'
            : 'Failed to add expense.';

        $this->redirect('expenses/index');
    }

    public function delete($id): void
    {
        $this->requireLogin();

        $expenseModel = $this->model('Expense');
        $ok = $expenseModel->delete((int)$id);

        $_SESSION[$ok ? 'success' : 'error'] = $ok
            ? 'Expense deleted successfully.'
            : 'Failed to delete expense.';

        $this->redirect('expenses/index');
    }
}
