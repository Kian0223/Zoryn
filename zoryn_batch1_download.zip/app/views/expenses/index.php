<?php require APP_PATH . '/views/layouts/header.php'; ?>
<div class="zoryn-admin-shell">
    <?php require APP_PATH . '/views/layouts/sidebar.php'; ?>
    <main class="zoryn-main-content">
        <section class="d-flex justify-content-between align-items-start gap-3 mb-4">
            <div>
                <div class="zoryn-hero-kicker">Financial Tracking</div>
                <h1 class="zoryn-page-title mb-2">Expenses</h1>
                <p class="zoryn-page-subtitle mb-0">
                    This month: <strong>₱<?= number_format((float)$month_total, 2); ?></strong>
                </p>
            </div>
        </section>

        <?php require APP_PATH . '/views/partials/alerts.php'; ?>

        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <form method="GET" action="<?= $config['base_url']; ?>/expenses/index">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label">Date From</label>
                            <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from); ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Date To</label>
                            <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to); ?>">
                        </div>
                        <div class="col-md-2 d-grid">
                            <button class="btn btn-dark">Filter</button>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <div class="zoryn-mini-stat">
                                <span>Filtered Total</span>
                                <strong>₱<?= number_format((float)$range_total, 2); ?></strong>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Add Expense</h5>
                </div>
                <form method="POST" action="<?= $config['base_url']; ?>/expenses/store">
                    <div class="row g-3">
                        <div class="col-md-2">
                            <label class="form-label">Date</label>
                            <input type="date" name="expense_date" class="form-control" value="<?= date('Y-m-d'); ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Description</label>
                            <input type="text" name="description" class="form-control" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Category</label>
                            <select name="category" class="form-select">
                                <option value="Ingredients">Ingredients</option>
                                <option value="Utilities">Utilities</option>
                                <option value="Salaries">Salaries</option>
                                <option value="Marketing">Marketing</option>
                                <option value="Maintenance">Maintenance</option>
                                <option value="Rent">Rent</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Amount</label>
                            <input type="number" step="0.01" min="0.01" name="amount" class="form-control" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Payment</label>
                            <select name="payment_method" class="form-select">
                                <option value="Cash">Cash</option>
                                <option value="Bank Transfer">Bank Transfer</option>
                                <option value="Card">Card</option>
                                <option value="GCash">GCash</option>
                                <option value="Maya">Maya</option>
                            </select>
                        </div>
                        <div class="col-md-1 d-grid">
                            <label class="form-label opacity-0">Save</label>
                            <button class="btn btn-dark">Save</button>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Notes</label>
                            <input type="text" name="notes" class="form-control" placeholder="Optional note">
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-lg-4">
                <div class="zoryn-panel h-100">
                    <div class="zoryn-panel-header">
                        <div>
                            <div class="zoryn-panel-kicker">Breakdown</div>
                            <h5 class="mb-0">Expense Categories</h5>
                        </div>
                    </div>
                    <div class="zoryn-summary-list">
                        <?php foreach ($category_breakdown as $row): ?>
                            <div class="zoryn-summary-item">
                                <span><?= htmlspecialchars($row['category']); ?></span>
                                <strong>₱<?= number_format((float)$row['total'], 2); ?></strong>
                            </div>
                        <?php endforeach; ?>
                        <?php if (empty($category_breakdown)): ?>
                            <div class="text-muted">No expense breakdown yet.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-body table-responsive">
                        <table class="table zoryn-table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Description</th>
                                    <th>Category</th>
                                    <th>Amount</th>
                                    <th>Payment</th>
                                    <th width="90"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($expenses as $expense): ?>
                                    <tr>
                                        <td><?= htmlspecialchars(date('M d, Y', strtotime($expense['expense_date']))); ?></td>
                                        <td><?= htmlspecialchars($expense['description']); ?></td>
                                        <td><span class="zoryn-table-pill"><?= htmlspecialchars($expense['category']); ?></span></td>
                                        <td class="fw-semibold">₱<?= number_format((float)$expense['amount'], 2); ?></td>
                                        <td><?= htmlspecialchars($expense['payment_method'] ?: '-'); ?></td>
                                        <td>
                                            <a class="btn btn-sm btn-danger" onclick="return confirm('Delete this expense?')" href="<?= $config['base_url']; ?>/expenses/delete/<?= (int)$expense['id']; ?>">Del</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($expenses)): ?>
                                    <tr><td colspan="6" class="text-center text-muted">No expenses found for the selected dates.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<?php require APP_PATH . '/views/layouts/footer.php'; ?>
