ZORYN BATCH 20 INSTALLATION
===========================

This batch adds:
- Supplier purchase orders
- Convert approved plans into POs
- Print-ready PO view
- Receiving draft generation tied to PO source

INSTALL ORDER
-------------
1. Run: sql/batch20_purchase_orders.sql
2. Copy the PHP files into your project folders
3. Merge public/assets/css/batch20.css if you want the extra styling

ROUTES ADDED
------------
/supplierpurchaseorders/index
/supplierpurchaseorders/createFromPlan/{planId}
/supplierpurchaseorders/issue/{poId}
/supplierpurchaseorders/print/{poId}
/supplierpurchaseorders/createReceivingFromPO/{poId}

NOTES
-----
- Approved purchase plans are split into one PO per supplier.
- Receiving drafts generated from POs are saved into grocery_purchases with source_po_id.
- PO print page is built to be PDF-ready through browser print/export.
