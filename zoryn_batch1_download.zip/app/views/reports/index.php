<?php require APP_PATH . '/views/layouts/header.php'; ?>
<div class="zoryn-admin-shell">
    <?php require APP_PATH . '/views/layouts/sidebar.php'; ?>
    <main class="zoryn-main-content">
        <section class="d-flex justify-content-between align-items-start gap-3 mb-4">
            <div>
                <div class="zoryn-hero-kicker">Deep Insights</div>
                <h1 class="zoryn-page-title mb-2">Reports & Analytics</h1>
                <p class="zoryn-page-subtitle mb-0">Deep insights into your restaurant performance.</p>
            </div>
        </section>

        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <form method="GET" action="<?= $config['base_url']; ?>/reports/index">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label">Date From</label>
                            <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from); ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Date To</label>
                            <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to); ?>">
                        </div>
                        <div class="col-md-2 d-grid">
                            <button class="btn btn-dark">Apply</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <section class="row g-4 mb-4">
            <div class="col-md-6 col-xl-3">
                <div class="zoryn-stat-card">
                    <div class="zoryn-stat-label">Total Revenue</div>
                    <div class="zoryn-stat-value">₱<?= number_format((float)$summary['total_sales'], 2); ?></div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3">
                <div class="zoryn-stat-card">
                    <div class="zoryn-stat-label">Orders</div>
                    <div class="zoryn-stat-value"><?= (int)$summary['total_receipts']; ?></div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3">
                <div class="zoryn-stat-card">
                    <div class="zoryn-stat-label">Avg Order</div>
                    <div class="zoryn-stat-value">₱<?= number_format((float)$summary['avg_order'], 2); ?></div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3">
                <div class="zoryn-stat-card">
                    <div class="zoryn-stat-label">Net Profit</div>
                    <div class="zoryn-stat-value <?= $net_profit < 0 ? 'text-danger' : 'text-success'; ?>">
                        ₱<?= number_format((float)$net_profit, 2); ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="row g-4 mb-4">
            <div class="col-xl-8">
                <div class="zoryn-panel h-100">
                    <div class="zoryn-panel-header">
                        <div>
                            <div class="zoryn-panel-kicker">Trend</div>
                            <h5 class="mb-0">Revenue Trend</h5>
                        </div>
                    </div>
                    <canvas id="revenueTrendChart" height="120"></canvas>
                </div>
            </div>

            <div class="col-xl-4">
                <div class="zoryn-panel h-100">
                    <div class="zoryn-panel-header">
                        <div>
                            <div class="zoryn-panel-kicker">Timing</div>
                            <h5 class="mb-0">Orders by Hour</h5>
                        </div>
                    </div>
                    <canvas id="ordersByHourChart" height="120"></canvas>
                </div>
            </div>
        </section>

        <section class="row g-4 mb-4">
            <div class="col-12">
                <div class="zoryn-panel">
                    <div class="zoryn-panel-header">
                        <div>
                            <div class="zoryn-panel-kicker">Best Performers</div>
                            <h5 class="mb-0">Top Selling Items</h5>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table zoryn-table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Item</th>
                                    <th>Type</th>
                                    <th>Qty Sold</th>
                                    <th>Revenue</th>
                                    <th>Avg Price</th>
                                    <th>Profit per Unit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_items as $index => $item): ?>
                                    <tr>
                                        <td><span class="zoryn-rank-pill"><?= $index + 1; ?></span></td>
                                        <td><?= htmlspecialchars($item['item_name']); ?></td>
                                        <td><?= htmlspecialchars($item['item_type']); ?></td>
                                        <td><?= number_format((float)$item['qty_sold'], 2); ?></td>
                                        <td>₱<?= number_format((float)$item['revenue'], 2); ?></td>
                                        <td>₱<?= number_format((float)$item['avg_price'], 2); ?></td>
                                        <td class="<?= (float)$item['profit_per_unit'] >= 0 ? 'text-success fw-semibold' : 'text-danger fw-semibold'; ?>">
                                            ₱<?= number_format((float)$item['profit_per_unit'], 2); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($top_items)): ?>
                                    <tr><td colspan="7" class="text-center text-muted">No sales found for the selected dates.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <section class="row g-4">
            <div class="col-xl-7">
                <div class="card shadow-sm border-0">
                    <div class="card-body table-responsive">
                        <h5 class="mb-3">Sales List</h5>
                        <table class="table zoryn-table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Receipt</th>
                                    <th>Date</th>
                                    <th>Cashier</th>
                                    <th>Items</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sales as $sale): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($sale['receipt_no']); ?></td>
                                        <td><?= htmlspecialchars(date('M d, Y h:i A', strtotime($sale['sale_date']))); ?></td>
                                        <td><?= htmlspecialchars($sale['cashier_name'] ?? '-'); ?></td>
                                        <td>
                                            <?php foreach (($sale['items'] ?? []) as $item): ?>
                                                <div><?= htmlspecialchars($item['item_name'] ?? '-'); ?> x <?= number_format((float)$item['quantity'], 2); ?></div>
                                            <?php endforeach; ?>
                                        </td>
                                        <td>₱<?= number_format((float)$sale['total_amount'], 2); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($sales)): ?>
                                    <tr><td colspan="5" class="text-center text-muted">No sales found for the selected dates.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-xl-5">
                <div class="zoryn-panel h-100">
                    <div class="zoryn-panel-header">
                        <div>
                            <div class="zoryn-panel-kicker">Profit & Loss</div>
                            <h5 class="mb-0">Summary</h5>
                        </div>
                    </div>

                    <div class="zoryn-pnl-list">
                        <div class="zoryn-pnl-item zoryn-pnl-positive">
                            <span><i class="bi bi-arrow-up-right"></i> Revenue</span>
                            <strong>₱<?= number_format((float)$summary['total_sales'], 2); ?></strong>
                        </div>
                        <div class="zoryn-pnl-item zoryn-pnl-negative">
                            <span><i class="bi bi-arrow-down-right"></i> Expenses</span>
                            <strong>₱<?= number_format((float)$expense_total, 2); ?></strong>
                        </div>
                        <div class="zoryn-pnl-item <?= $net_profit < 0 ? 'zoryn-pnl-negative' : 'zoryn-pnl-positive'; ?>">
                            <span><i class="bi bi-activity"></i> Net Profit</span>
                            <strong>₱<?= number_format((float)$net_profit, 2); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const revenueTrendLabels = <?= json_encode(array_map(fn($row) => date('M j', strtotime($row['trend_date'])), $revenue_trend)); ?>;
const revenueTrendData = <?= json_encode(array_map(fn($row) => (float)$row['total'], $revenue_trend)); ?>;

const hourMap = Array.from({ length: 24 }, (_, hour) => {
    const found = <?= json_encode($orders_by_hour); ?>.find(row => parseInt(row.order_hour, 10) === hour);
    return found ? parseInt(found.total_orders, 10) : 0;
});

new Chart(document.getElementById('revenueTrendChart'), {
    type: 'line',
    data: {
        labels: revenueTrendLabels,
        datasets: [{
            label: 'Revenue',
            data: revenueTrendData,
            borderColor: '#d4af37',
            backgroundColor: 'rgba(212, 175, 55, 0.12)',
            tension: 0.25,
            fill: true
        }]
    },
    options: {
        plugins: { legend: { display: false } },
        scales: {
            x: { ticks: { color: '#f6f1df' }, grid: { color: 'rgba(212,175,55,0.08)' } },
            y: { ticks: { color: '#f6f1df' }, grid: { color: 'rgba(212,175,55,0.08)' } }
        }
    }
});

new Chart(document.getElementById('ordersByHourChart'), {
    type: 'bar',
    data: {
        labels: Array.from({ length: 24 }, (_, hour) => hour + ':00'),
        datasets: [{
            label: 'Orders',
            data: hourMap,
            backgroundColor: 'rgba(212, 175, 55, 0.85)'
        }]
    },
    options: {
        plugins: { legend: { display: false } },
        scales: {
            x: { ticks: { color: '#f6f1df', maxRotation: 90, minRotation: 90 }, grid: { color: 'rgba(212,175,55,0.08)' } },
            y: { beginAtZero: true, ticks: { color: '#f6f1df' }, grid: { color: 'rgba(212,175,55,0.08)' } }
        }
    }
});
</script>

<?php require APP_PATH . '/views/layouts/footer.php'; ?>
