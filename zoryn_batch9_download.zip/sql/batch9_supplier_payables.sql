CREATE TABLE IF NOT EXISTS supplier_payments (
  id INT(11) NOT NULL AUTO_INCREMENT,
  supplier_id INT(11) NOT NULL,
  purchase_id INT(11) DEFAULT NULL,
  payment_date DATE NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  payment_method ENUM('cash','gcash','bank_transfer','check') NOT NULL DEFAULT 'cash',
  reference_no VARCHAR(100) DEFAULT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  created_by INT(11) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE grocery_purchases
  ADD COLUMN amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER total_amount,
  ADD COLUMN balance_due DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER amount_paid,
  ADD COLUMN payment_status ENUM('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid' AFTER balance_due;
